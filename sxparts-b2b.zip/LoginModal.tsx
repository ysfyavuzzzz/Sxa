// Bu dosya LoginPage.tsx ile değiştirildiği için silinmiştir.
// İçeriği LoginPage.tsx'e taşınmış ve tam sayfa görünümüne uyarlanmıştır.
