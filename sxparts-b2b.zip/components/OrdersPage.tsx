
import React, { useState } from 'react';
import { Order, User, OrderStatus, CartItem } from '../types';
import DocumentTextIcon from './icons/DocumentTextIcon'; 

interface OrdersPageProps {
  orders: Order[];
  currentUser: User;
  onNavigateToCatalog: () => void;
  onNavigateToOrderDetail: (orderId: string) => void; // Yeni prop
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus, adminNotes?: string) => void;
  onUploadPaymentProof: (orderId: string, fileName: string, customerNotes: string) => void;
  onUploadContainerPhoto: (orderId: string, fileName: string) => void;
}

const OrdersPage: React.FC<OrdersPageProps> = ({ 
    orders, 
    currentUser, 
    onNavigateToCatalog,
    onNavigateToOrderDetail, // Prop olarak alındı
    onUpdateOrderStatus,
    onUploadPaymentProof,
    onUploadContainerPhoto
}) => {
  
  const pageTitle = (currentUser.role === 'user' || currentUser.role === 'manager' && orders.every(o => o.userId === currentUser.id)) 
    ? 'Siparişlerim' 
    : 'Tüm Siparişler';

  const [selectedOrderIdForProof, setSelectedOrderIdForProof] = useState<string | null>(null);
  const [paymentFile, setPaymentFile] = useState<File | null>(null);
  const [customerOrderNotes, setCustomerOrderNotes] = useState<string>('');
  
  const [selectedOrderIdForContainer, setSelectedOrderIdForContainer] = useState<string | null>(null);
  const [containerFile, setContainerFile] = useState<File | null>(null);
  
  const [editingStatusOrderId, setEditingStatusOrderId] = useState<string | null>(null);
  const [newStatusForOrder, setNewStatusForOrder] = useState<OrderStatus | ''>('');
  const [adminOrderNotes, setAdminOrderNotes] = useState<string>('');


  const handlePaymentProofSubmit = (orderId: string) => {
    if (paymentFile) {
      onUploadPaymentProof(orderId, paymentFile.name, customerOrderNotes);
      setSelectedOrderIdForProof(null);
      setPaymentFile(null);
      setCustomerOrderNotes('');
      alert("Ödeme bildirimi başarıyla gönderildi.");
    } else {
      alert("Lütfen bir dosya seçin.");
    }
  };
  
  const handleContainerPhotoSubmit = (orderId: string) => {
    if (containerFile) {
      onUploadContainerPhoto(orderId, containerFile.name);
      setSelectedOrderIdForContainer(null);
      setContainerFile(null);
      alert("Konteyner fotoğrafı başarıyla yüklendi.");
    } else {
      alert("Lütfen bir dosya seçin.");
    }
  };

  const handleStatusUpdateSubmit = (orderId: string) => {
    if (newStatusForOrder) {
      onUpdateOrderStatus(orderId, newStatusForOrder, adminOrderNotes);
      setEditingStatusOrderId(null);
      setNewStatusForOrder('');
      setAdminOrderNotes('');
      alert("Sipariş durumu başarıyla güncellendi.");
    } else {
      alert("Lütfen yeni bir durum seçin.");
    }
  };


  const getStatusClass = (status: OrderStatus): string => {
    switch (status) {
      case OrderStatus.ORDER_CONFIRMED: return 'bg-cyan-100 text-cyan-800';
      case OrderStatus.AWAITING_PAYMENT: return 'bg-yellow-100 text-yellow-800';
      case OrderStatus.PAYMENT_PROOF_UPLOADED: return 'bg-blue-100 text-blue-800';
      case OrderStatus.PAYMENT_CONFIRMED: return 'bg-indigo-100 text-indigo-800';
      case OrderStatus.PROCESSING: return 'bg-purple-100 text-purple-800';
      case OrderStatus.SHIPPED: return 'bg-orange-100 text-orange-800';
      case OrderStatus.IN_TRANSIT: return 'bg-lime-100 text-lime-800';
      case OrderStatus.IN_CUSTOMS: return 'bg-pink-100 text-pink-800';
      case OrderStatus.NEARING_DELIVERY: return 'bg-teal-100 text-teal-800';
      case OrderStatus.DELIVERED: return 'bg-green-100 text-green-800';
      case OrderStatus.CANCELLED: return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  const isAdminView = currentUser.role === 'super_admin' || currentUser.role === 'manager';

  return (
    <main className="flex-grow container mx-auto px-2 sm:px-4 lg:px-6 py-8">
      <div className="bg-white shadow-xl rounded-lg p-4 md:p-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <div className="flex items-center mb-4 sm:mb-0">
            <DocumentTextIcon className="w-8 h-8 sm:w-10 sm:h-10 mr-3 text-orange-600" />
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-800">
              {pageTitle}
            </h1>
          </div>
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-4 sm:px-6 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 self-start sm:self-center text-sm sm:text-base"
            aria-label="Kataloğa Geri Dön"
          >
            Kataloğa Dön
          </button>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-12">
             <DocumentTextIcon className="w-20 h-20 sm:w-24 sm:h-24 mx-auto text-gray-300 mb-4" />
            <p className="text-lg sm:text-xl text-gray-600 mb-2">Henüz siparişiniz bulunmamaktadır.</p>
            {currentUser.role === 'user' && <p className="text-gray-500">İlk siparişinizi vermek için kataloğumuza göz atın!</p>}
          </div>
        ) : (
          <div className="space-y-6">
            {orders.sort((a, b) => b.orderDate.getTime() - a.orderDate.getTime()).map(order => (
              <div key={order.id} className="bg-gray-50 border border-gray-200 rounded-lg shadow-sm p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-3 mb-3 pb-3 border-b">
                  <div>
                    <strong className="text-sm text-gray-500 block">Sipariş No:</strong>
                    <span 
                      className="text-orange-700 font-semibold text-sm cursor-pointer hover:underline" 
                      title={`Detayları gör: ${order.id}`}
                      onClick={() => onNavigateToOrderDetail(order.id)}
                      role="link"
                      tabIndex={0}
                      onKeyDown={(e) => e.key === 'Enter' && onNavigateToOrderDetail(order.id)}
                    >
                      {order.id.substring(0,15)}...
                    </span>
                  </div>
                  <div>
                    <strong className="text-sm text-gray-500 block">Tarih:</strong>
                    <span className="text-gray-700 text-sm">{new Date(order.orderDate).toLocaleDateString('tr-TR', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                  </div>
                  <div>
                    <strong className="text-sm text-gray-500 block">Toplam Tutar:</strong>
                    <span className="text-gray-800 font-bold text-sm">${order.grandTotal.toFixed(2)}</span>
                  </div>
                  <div>
                    <strong className="text-sm text-gray-500 block">Durum:</strong>
                    <span className={`px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClass(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                   {isAdminView && order.userId !== currentUser.id && (
                     <div className="md:col-span-1 lg:col-span-4">
                        <strong className="text-sm text-gray-500 block">Müşteri ID:</strong>
                        <span className="text-gray-700 text-sm" title={order.userId}>{order.userId}</span>
                     </div>
                   )}
                </div>

                {/* Sipariş Ürünleri (Açılır Kapanır Olabilir) */}
                <details className="text-sm mb-3">
                    <summary className="cursor-pointer text-orange-600 hover:underline font-medium" onClick={(e) => e.preventDefault()}>
                        Sipariş Detayları ({order.items.reduce((acc, item) => acc + item.quantity, 0)} ürün) - Görmek için Sipariş No'ya tıklayın.
                    </summary>
                     {/* Detaylar artık OrderDetailPage'de gösterilecek. İstenirse buraya da basit bir liste eklenebilir.
                    <ul className="list-disc list-inside mt-2 pl-4 space-y-1 text-gray-600">
                        {order.items.map(item => (
                            <li key={item.product.id}>
                                {item.product.name} x {item.quantity} (Birim: ${ (item.product.price * (1 - (order.subtotal > 0 ? order.discountApplied / order.subtotal : 0))).toFixed(2) })
                            </li>
                        ))}
                    </ul>
                    */}
                </details>
                
                {/* Notlar */}
                 {(order.customerNotes || order.adminNotes || order.paymentProofUrl || order.containerPhotoUrl) && (
                    <div className="mb-3 p-3 bg-slate-100 rounded-md text-xs space-y-1">
                        {order.customerNotes && <p><strong>Müşteri Notu:</strong> {order.customerNotes}</p>}
                        {order.paymentProofUrl && <p><strong>Ödeme Kanıtı:</strong> <a href="#" onClick={(e) => {e.preventDefault(); alert("Simüle edilmiş dosya linki. Gerçek uygulamada dosya açılır.")}} className="text-orange-600 hover:underline">{order.paymentProofUrl.split('/').pop()} (simüle)</a></p>}
                        {order.adminNotes && <p><strong>Yönetici Notu:</strong> {order.adminNotes}</p>}
                        {order.containerPhotoUrl && <p><strong>Konteyner F.:</strong> <a href="#" onClick={(e) => {e.preventDefault(); alert("Simüle edilmiş dosya linki. Gerçek uygulamada dosya açılır.")}} className="text-orange-600 hover:underline">{order.containerPhotoUrl.split('/').pop()} (simüle)</a></p>}
                    </div>
                 )}


                {/* Müşteri Aksiyonları */}
                {!isAdminView && (order.status === OrderStatus.ORDER_CONFIRMED || order.status === OrderStatus.AWAITING_PAYMENT) && !order.paymentProofUrl && (
                  <div className="mt-3 pt-3 border-t">
                    <p className="text-sm text-amber-700 mb-2">Siparişiniz ödeme onayı bekliyor. Lütfen ödeme yaptığınıza dair makbuzu yükleyin.</p>
                    {selectedOrderIdForProof === order.id ? (
                      <div className="space-y-2">
                        <input type="file" onChange={(e) => setPaymentFile(e.target.files ? e.target.files[0] : null)} className="text-xs p-1 border rounded w-full" />
                        <textarea value={customerOrderNotes} onChange={(e) => setCustomerOrderNotes(e.target.value)} placeholder="Ek notlarınız (isteğe bağlı)" className="w-full text-xs p-1 border rounded" rows={2}></textarea>
                        <button onClick={() => handlePaymentProofSubmit(order.id)} className="text-xs bg-green-500 hover:bg-green-600 text-white py-1 px-2 rounded">Gönder</button>
                        <button onClick={() => setSelectedOrderIdForProof(null)} className="text-xs bg-gray-300 hover:bg-gray-400 text-black py-1 px-2 rounded ml-2">İptal</button>
                      </div>
                    ) : (
                      <button onClick={() => setSelectedOrderIdForProof(order.id)} className="bg-orange-500 hover:bg-orange-600 text-white py-1.5 px-3 rounded text-sm">Ödeme Makbuzu Yükle</button>
                    )}
                  </div>
                )}

                {/* Yönetici Aksiyonları */}
                {isAdminView && (
                  <div className="mt-3 pt-3 border-t">
                    {editingStatusOrderId === order.id ? (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 items-end">
                        <select value={newStatusForOrder} onChange={(e) => setNewStatusForOrder(e.target.value as OrderStatus)} className="text-xs p-1.5 border rounded w-full">
                          <option value="" disabled>Durum Seçin</option>
                          {Object.values(OrderStatus).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <textarea value={adminOrderNotes} onChange={e => setAdminOrderNotes(e.target.value)} placeholder="Yönetici Notu (isteğe bağlı)" className="w-full text-xs p-1.5 border rounded sm:col-span-2" rows={1}></textarea>
                        <div className="sm:col-span-3 flex gap-2 mt-1">
                            <button onClick={() => handleStatusUpdateSubmit(order.id)} className="text-xs bg-green-500 hover:bg-green-600 text-white py-1 px-2 rounded">Kaydet</button>
                            <button onClick={() => {setEditingStatusOrderId(null); setNewStatusForOrder(''); setAdminOrderNotes('')}} className="text-xs bg-gray-300 hover:bg-gray-400 text-black py-1 px-2 rounded">İptal</button>
                        </div>
                      </div>
                    ) : (
                      <button onClick={() => { setEditingStatusOrderId(order.id); setNewStatusForOrder(order.status); setAdminOrderNotes(order.adminNotes || '');}} className="bg-orange-500 hover:bg-orange-600 text-white py-1.5 px-3 rounded text-sm">Durumu Güncelle</button>
                    )}

                    {(order.status === OrderStatus.PROCESSING || order.status === OrderStatus.SHIPPED || order.status === OrderStatus.IN_TRANSIT || order.status === OrderStatus.IN_CUSTOMS ) && (
                        <div className="mt-2">
                        {selectedOrderIdForContainer === order.id ? (
                             <div className="flex items-center gap-2">
                                <input type="file" onChange={(e) => setContainerFile(e.target.files ? e.target.files[0] : null)} className="text-xs p-1 border rounded w-full sm:w-auto"/>
                                <button onClick={() => handleContainerPhotoSubmit(order.id)} className="text-xs bg-green-500 hover:bg-green-600 text-white py-1 px-2 rounded">Yükle</button>
                                <button onClick={() => setSelectedOrderIdForContainer(null)} className="text-xs bg-gray-300 hover:bg-gray-400 text-black py-1 px-2 rounded">İptal</button>
                             </div>
                        ) : (
                             <button onClick={() => setSelectedOrderIdForContainer(order.id)} className="bg-teal-500 hover:bg-teal-600 text-white py-1.5 px-3 rounded text-sm ml-0 sm:ml-2 mt-2 sm:mt-0">Konteyner Fotoğrafı</button>
                        )}
                        </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
};

export default OrdersPage;