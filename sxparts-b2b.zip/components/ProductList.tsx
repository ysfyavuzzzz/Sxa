import React from 'react';
import { Product, User } from '../types';
import ProductCard from './ProductCard';
import LoadingSpinner from './LoadingSpinner';

interface ProductListProps {
  products: Product[];
  isLoading: boolean;
  onSoftDeleteProduct?: (productId: string) => void;
  currentUser: User;
  onAddToCart: (product: Product, quantity: number) => void; // onAddToCart prop'u eklendi
}

const ProductList: React.FC<ProductListProps> = ({ 
  products, 
  isLoading, 
  onSoftDeleteProduct, 
  currentUser,
  onAddToCart // onAddToCart prop'u eklendi
}) => {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500">
        <p className="text-xl">Ürün bulunamadı.</p>
        <p>Arama, kategori filtrelerinizi veya kullanıcı erişim ayarlarınızı kontrol edin.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard 
            key={product.id} 
            product={product} 
            onSoftDelete={onSoftDeleteProduct} 
            currentUser={currentUser} 
            onAddToCart={onAddToCart} // onAddToCart prop'u ProductCard'a iletildi
        />
      ))}
    </div>
  );
};

export default ProductList;