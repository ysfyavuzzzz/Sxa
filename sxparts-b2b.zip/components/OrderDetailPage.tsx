
import React, { useState } from 'react';
import { Order, User, OrderStatus, CartItem } from '../types';

interface OrderDetailPageProps {
  order: Order;
  currentUser: User;
  onNavigateBack: () => void;
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus, adminNotes?: string) => void;
  onUploadPaymentProof: (orderId: string, fileName: string, customerNotes: string) => void;
  onUploadContainerPhoto: (orderId: string, fileName: string) => void;
}

const OrderStatusStepper: React.FC<{ currentStatus: OrderStatus }> = ({ currentStatus }) => {
  const statusesInOrder: OrderStatus[] = [
    OrderStatus.ORDER_CONFIRMED,
    OrderStatus.AWAITING_PAYMENT,
    OrderStatus.PAYMENT_PROOF_UPLOADED,
    OrderStatus.PAYMENT_CONFIRMED,
    OrderStatus.PROCESSING,
    OrderStatus.SHIPPED,
    OrderStatus.IN_TRANSIT,
    OrderStatus.IN_CUSTOMS,
    OrderStatus.NEARING_DELIVERY,
    OrderStatus.DELIVERED,
  ];

  const currentIndex = statusesInOrder.indexOf(currentStatus);

  if (currentStatus === OrderStatus.CANCELLED) {
    return (
      <div className="my-6 p-4 bg-red-50 border border-red-200 rounded-md text-center">
        <p className="text-xl font-semibold text-red-700">Sipariş İptal Edildi</p>
      </div>
    );
  }

  return (
    <div className="my-8 overflow-x-auto pb-4">
      <div className="flex items-center min-w-max">
        {statusesInOrder.map((status, index) => {
          const isActive = index === currentIndex;
          const isCompleted = index < currentIndex;
          const isFuture = index > currentIndex;

          let bgColor = 'bg-gray-300';
          let textColor = 'text-gray-500';
          let borderColor = 'border-gray-300';

          if (isCompleted) {
            bgColor = 'bg-green-500';
            textColor = 'text-white';
            borderColor = 'border-green-500';
          } else if (isActive) {
            bgColor = 'bg-orange-500';
            textColor = 'text-white';
            borderColor = 'border-orange-500';
          }

          return (
            <React.Fragment key={status}>
              <div className="flex flex-col items-center">
                <div 
                  className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border-2 ${borderColor} ${bgColor} ${textColor} font-semibold text-sm sm:text-base transition-all duration-300`}
                  title={status}
                >
                  {isCompleted ? '✓' : index + 1}
                </div>
                <p className={`mt-2 text-xs sm:text-sm text-center w-20 sm:w-24 break-words ${isActive ? 'text-orange-600 font-semibold' : (isCompleted ? 'text-green-700' : 'text-gray-500')}`}>
                  {status}
                </p>
              </div>
              {index < statusesInOrder.length - 1 && (
                <div className={`flex-1 h-1 mx-1 sm:mx-2 ${isCompleted ? 'bg-green-500' : (isActive ? 'bg-orange-200' : 'bg-gray-300')} transition-all duration-300`}></div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};


const OrderDetailPage: React.FC<OrderDetailPageProps> = ({
  order,
  currentUser,
  onNavigateBack,
  onUpdateOrderStatus,
  onUploadPaymentProof,
  onUploadContainerPhoto
}) => {
  const [paymentFile, setPaymentFile] = useState<File | null>(null);
  const [customerOrderNotes, setCustomerOrderNotes] = useState<string>(order.customerNotes || '');
  const [containerFile, setContainerFile] = useState<File | null>(null);
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatusForOrder, setNewStatusForOrder] = useState<OrderStatus>(order.status);
  const [adminOrderNotes, setAdminOrderNotes] = useState<string>(order.adminNotes || '');

  const isAdminView = currentUser.role === 'super_admin' || currentUser.role === 'manager';

  const handlePaymentProofSubmit = () => {
    if (paymentFile) {
      onUploadPaymentProof(order.id, paymentFile.name, customerOrderNotes);
      setPaymentFile(null);
      // customerOrderNotes state'i zaten güncel
      alert("Ödeme bildirimi başarıyla gönderildi. Sayfa güncelleniyor...");
    } else {
      alert("Lütfen bir dosya seçin.");
    }
  };

  const handleContainerPhotoSubmit = () => {
    if (containerFile) {
      onUploadContainerPhoto(order.id, containerFile.name);
      setContainerFile(null);
      alert("Konteyner fotoğrafı başarıyla yüklendi. Sayfa güncelleniyor...");
    } else {
      alert("Lütfen bir dosya seçin.");
    }
  };

  const handleStatusUpdateSubmit = () => {
    if (newStatusForOrder) {
      onUpdateOrderStatus(order.id, newStatusForOrder, adminOrderNotes);
      setEditingStatus(false);
      alert("Sipariş durumu başarıyla güncellendi. Sayfa güncelleniyor...");
    } else {
      alert("Lütfen yeni bir durum seçin.");
    }
  };
  
  const getStatusClass = (status: OrderStatus): string => {
    // OrdersPage'deki ile aynı fonksiyonu kullanabiliriz veya buraya kopyalayabiliriz.
    // Şimdilik kopyalıyorum, idealde ortak bir helper'a taşınabilir.
    switch (status) {
      case OrderStatus.ORDER_CONFIRMED: return 'bg-cyan-100 text-cyan-800';
      case OrderStatus.AWAITING_PAYMENT: return 'bg-yellow-100 text-yellow-800';
      case OrderStatus.PAYMENT_PROOF_UPLOADED: return 'bg-blue-100 text-blue-800';
      case OrderStatus.PAYMENT_CONFIRMED: return 'bg-indigo-100 text-indigo-800';
      case OrderStatus.PROCESSING: return 'bg-purple-100 text-purple-800';
      case OrderStatus.SHIPPED: return 'bg-orange-100 text-orange-800';
      case OrderStatus.IN_TRANSIT: return 'bg-lime-100 text-lime-800';
      case OrderStatus.IN_CUSTOMS: return 'bg-pink-100 text-pink-800';
      case OrderStatus.NEARING_DELIVERY: return 'bg-teal-100 text-teal-800';
      case OrderStatus.DELIVERED: return 'bg-green-100 text-green-800';
      case OrderStatus.CANCELLED: return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };


  return (
    <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-800 mb-4 sm:mb-0">
            Sipariş Detayı: #{order.id}
          </h1>
          <button
            onClick={onNavigateBack}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 self-start sm:self-center"
            aria-label="Sipariş Listesine Geri Dön"
          >
            Sipariş Listesine Dön
          </button>
        </div>

        <OrderStatusStepper currentStatus={order.status} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold text-slate-700 mb-2">Sipariş Bilgileri</h3>
            <p className="text-sm"><strong className="text-gray-600">Sipariş Tarihi:</strong> {new Date(order.orderDate).toLocaleString('tr-TR')}</p>
            <p className="text-sm"><strong className="text-gray-600">Durum:</strong> <span className={`px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClass(order.status)}`}>{order.status}</span></p>
            {isAdminView && <p className="text-sm"><strong className="text-gray-600">Müşteri ID:</strong> {order.userId}</p>}
            {order.customerNotes && <p className="text-sm mt-1"><strong className="text-gray-600">Müşteri Notları:</strong> {order.customerNotes}</p>}
            {order.adminNotes && <p className="text-sm mt-1"><strong className="text-gray-600">Yönetici Notları:</strong> {order.adminNotes}</p>}
            {order.paymentProofUrl && <p className="text-sm mt-1"><strong className="text-gray-600">Ödeme Kanıtı:</strong> <a href="#" onClick={(e) => {e.preventDefault(); alert("Simüle edilmiş dosya linki.")}} className="text-orange-600 hover:underline">{order.paymentProofUrl.split('/').pop()} (simüle)</a></p>}
            {order.containerPhotoUrl && <p className="text-sm mt-1"><strong className="text-gray-600">Konteyner Fotoğrafı:</strong> <a href="#" onClick={(e) => {e.preventDefault(); alert("Simüle edilmiş dosya linki.")}} className="text-orange-600 hover:underline">{order.containerPhotoUrl.split('/').pop()} (simüle)</a></p>}
          </div>
          <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold text-slate-700 mb-2">Ödeme Detayları</h3>
            <p className="text-sm"><strong className="text-gray-600">Ara Toplam:</strong> ${order.subtotal.toFixed(2)}</p>
            <p className="text-sm"><strong className="text-gray-600">İndirim:</strong> -${order.discountApplied.toFixed(2)}</p>
            <p className="text-lg font-semibold"><strong className="text-gray-700">Genel Toplam:</strong> ${order.grandTotal.toFixed(2)}</p>
            <div className="mt-3 bg-blue-50 border border-blue-200 p-3 rounded-md">
                <h4 className="text-sm font-semibold text-blue-700 mb-1">Ödeme Yöntemi: EFT/Havale</h4>
                <p className="text-xs text-gray-700"><strong>Banka:</strong> Örnek Bank A.Ş.</p>
                <p className="text-xs text-gray-700"><strong>Hesap Sahibi:</strong> B2B Katalog Pro Tic. Ltd. Şti.</p>
                <p className="text-xs text-gray-700"><strong>IBAN:</strong> TR00 0000 0000 0000 0000 0000</p>
                 <p className="text-xs text-amber-700 mt-1">Not: Kredi kartı ile ödeme seçeneği şu anda aktif değildir.</p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-semibold text-slate-700 mb-4">Sipariş Edilen Ürünler</h3>
          <div className="space-y-3">
            {order.items.map(item => (
              <div key={item.product.id} className="bg-white border p-3 rounded-md flex items-center gap-4 shadow-sm">
                <img 
                    src={item.product.imageUrl} 
                    alt={item.product.name} 
                    className="w-16 h-16 object-cover rounded border"
                    onError={(e) => (e.currentTarget.src = 'https://picsum.photos/64/64?grayscale')}
                />
                <div className="flex-grow">
                  <p className="font-semibold text-slate-800">{item.product.name}</p>
                  <p className="text-xs text-gray-500">{item.product.category}</p>
                </div>
                <div className="text-sm text-right">
                  <p className="text-gray-600">{item.quantity} x ${ (item.product.price * (1 - (order.subtotal > 0 ? order.discountApplied / order.subtotal : 0))).toFixed(2) }</p>
                  <p className="font-semibold text-slate-700">${ (item.quantity * item.product.price * (1 - (order.subtotal > 0 ? order.discountApplied / order.subtotal : 0))).toFixed(2) }</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Müşteri Aksiyonları */}
        {!isAdminView && (order.status === OrderStatus.ORDER_CONFIRMED || order.status === OrderStatus.AWAITING_PAYMENT) && !order.paymentProofUrl && (
            <div className="mt-8 pt-6 border-t">
                <h3 className="text-lg font-semibold text-slate-700 mb-3">Ödeme Makbuzu Yükle</h3>
                <div className="space-y-3 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                    <input type="file" onChange={(e) => setPaymentFile(e.target.files ? e.target.files[0] : null)} className="text-sm p-2 border rounded w-full" />
                    <textarea value={customerOrderNotes} onChange={(e) => setCustomerOrderNotes(e.target.value)} placeholder="Ek notlarınız (isteğe bağlı)" className="w-full text-sm p-2 border rounded" rows={3}></textarea>
                    <button onClick={handlePaymentProofSubmit} disabled={!paymentFile} className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded text-sm disabled:opacity-50">
                        Makbuzu Gönder
                    </button>
                </div>
            </div>
        )}

        {/* Yönetici Aksiyonları */}
        {isAdminView && (
            <div className="mt-8 pt-6 border-t">
                 <h3 className="text-lg font-semibold text-slate-700 mb-3">Yönetici İşlemleri</h3>
                {editingStatus ? (
                    <div className="space-y-3 p-4 bg-indigo-50 border border-indigo-200 rounded-md">
                        <div>
                            <label htmlFor="newStatus" className="block text-sm font-medium text-gray-700 mb-1">Yeni Sipariş Durumu:</label>
                            <select id="newStatus" value={newStatusForOrder} onChange={(e) => setNewStatusForOrder(e.target.value as OrderStatus)} className="text-sm p-2 border rounded w-full sm:w-auto">
                                {Object.values(OrderStatus).map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div>
                             <label htmlFor="adminNotes" className="block text-sm font-medium text-gray-700 mb-1">Yönetici Notu:</label>
                            <textarea id="adminNotes" value={adminOrderNotes} onChange={e => setAdminOrderNotes(e.target.value)} placeholder="Yönetici Notu (isteğe bağlı)" className="w-full text-sm p-2 border rounded" rows={2}></textarea>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={handleStatusUpdateSubmit} className="bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-sm">Durumu Kaydet</button>
                            <button onClick={() => {setEditingStatus(false); setNewStatusForOrder(order.status); setAdminOrderNotes(order.adminNotes || '');}} className="bg-gray-300 hover:bg-gray-400 text-black py-2 px-3 rounded text-sm">İptal</button>
                        </div>
                    </div>
                ) : (
                    <button onClick={() => setEditingStatus(true)} className="bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded text-sm">
                        Sipariş Durumunu Güncelle
                    </button>
                )}

                {(order.status === OrderStatus.PROCESSING || order.status === OrderStatus.SHIPPED || order.status === OrderStatus.IN_TRANSIT || order.status === OrderStatus.IN_CUSTOMS ) && (
                    <div className="mt-4 p-4 bg-teal-50 border border-teal-200 rounded-md">
                        <h4 className="text-md font-semibold text-teal-700 mb-2">Konteyner Fotoğrafı</h4>
                        {order.containerPhotoUrl ? (
                             <p className="text-sm text-gray-600">Mevcut fotoğraf: <a href="#" onClick={(e) => {e.preventDefault(); alert("Simüle edilmiş dosya linki.")}} className="text-orange-600 hover:underline">{order.containerPhotoUrl.split('/').pop()}</a></p>
                        ) : (
                             <p className="text-sm text-gray-500 mb-2">Henüz konteyner fotoğrafı yüklenmemiş.</p>
                        )}
                        <input type="file" onChange={(e) => setContainerFile(e.target.files ? e.target.files[0] : null)} className="text-sm p-2 border rounded w-full mb-2" />
                        <button onClick={handleContainerPhotoSubmit} disabled={!containerFile} className="bg-teal-600 hover:bg-teal-700 text-white py-2 px-3 rounded text-sm disabled:opacity-50">
                            {order.containerPhotoUrl ? 'Fotoğrafı Güncelle' : 'Fotoğraf Yükle'}
                        </button>
                    </div>
                )}
            </div>
        )}

      </div>
    </main>
  );
};

export default OrderDetailPage;
