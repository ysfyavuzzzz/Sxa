
import React from 'react';
import { ChatMessage, GroundingChunk } from '../types';
import LoadingSpinner from './LoadingSpinner';

interface ChatMessageEntryProps {
  message: ChatMessage;
  groundingMetadata?: { groundingChunks?: GroundingChunk[] };
}

const ChatMessageEntry: React.FC<ChatMessageEntryProps> = ({ message, groundingMetadata }) => {
  const isUser = message.sender === 'user';

  const renderTextWithLinks = (text: string) => {
    const linkRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = linkRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push(text.substring(lastIndex, match.index));
      }
      parts.push(
        <a
          key={match.index}
          href={match[2]}
          target="_blank"
          rel="noopener noreferrer"
          className="text-orange-500 hover:text-orange-400 underline"
        >
          {match[1]}
        </a>
      );
      lastIndex = linkRegex.lastIndex;
    }

    if (lastIndex < text.length) {
      parts.push(text.substring(lastIndex));
    }
    
    return parts.map((part, index) => 
      typeof part === 'string' 
        ? part.split('\n').map((line, i) => <React.Fragment key={`${index}-${i}`}>{line}{i < part.split('\n').length - 1 && <br />}</React.Fragment>)
        : part
    );
  };
  
  return (
    <div className={`flex mb-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[80%] p-3 rounded-xl shadow ${
          isUser
            ? 'bg-orange-600 text-white rounded-br-none'
            : 'bg-white text-gray-800 rounded-bl-none border border-gray-200'
        }`}
      >
        {message.isLoading ? (
          <LoadingSpinner size="sm" color={isUser ? 'text-white' : 'text-orange-600'}/>
        ) : (
          <div className="whitespace-pre-wrap break-words">
            {renderTextWithLinks(message.text)}
          </div>
        )}
        {!isUser && groundingMetadata && groundingMetadata.groundingChunks && groundingMetadata.groundingChunks.length > 0 && (
          <div className="mt-2 pt-2 border-t border-gray-300">
            <p className="text-xs font-semibold text-gray-600 mb-1">Kaynaklar:</p>
            <ul className="list-disc list-inside space-y-0.5">
              {groundingMetadata.groundingChunks.map((chunk, index) => (
                chunk.web && (
                  <li key={index} className="text-xs">
                    <a 
                      href={chunk.web.uri} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-orange-700 hover:text-orange-500 hover:underline"
                      title={chunk.web.uri}
                    >
                      {chunk.web.title || chunk.web.uri}
                    </a>
                  </li>
                )
              ))}
            </ul>
          </div>
        )}
        <p className={`text-xs mt-1.5 ${isUser ? 'text-orange-200 text-right' : 'text-gray-500 text-left'}`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};

export default ChatMessageEntry;