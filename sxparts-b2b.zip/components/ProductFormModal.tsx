
import React, { useState, useEffect } from 'react';
import { Product, ProductCategory } from '../types';
import { generateProductDescription, generateProductImageUrl } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';

interface ProductFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (productData: Omit<Product, 'id' | 'isTrashed'> | Product) => void;
  existingProduct: Product | null;
  allCategories: ProductCategory[];
}

const ProductFormModal: React.FC<ProductFormModalProps> = ({ 
    isOpen, 
    onClose, 
    onSubmit, 
    existingProduct, 
    allCategories 
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ProductCategory>(allCategories[0] || ProductCategory.ELECTRONICS);
  const [price, setPrice] = useState(0);
  const [stock, setStock] = useState(0);
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  
  // Genel specifications
  const [specificationsString, setSpecificationsString] = useState('{}');
  
  // Otomotiv'e özel state'ler
  const [oem, setOem] = useState('');
  const [finishCode, setFinishCode] = useState('');
  const [vehicleBrand, setVehicleBrand] = useState('');

  const [isAiLoading, setIsAiLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (existingProduct) {
      setName(existingProduct.name);
      setCategory(existingProduct.category);
      setPrice(existingProduct.price);
      setStock(existingProduct.stock);
      setDescription(existingProduct.description);
      setImageUrl(existingProduct.imageUrl);

      if (existingProduct.category === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
        setOem(existingProduct.specifications?.Oem || '');
        setFinishCode(existingProduct.specifications?.['Finish Kodu'] || '');
        setVehicleBrand(existingProduct.specifications?.['Araç Markası'] || '');
        setSpecificationsString('{}'); // Otomotiv için genel JSON'u temizle/kullanma
      } else {
        setSpecificationsString(JSON.stringify(existingProduct.specifications || {}, null, 2));
        setOem(''); setFinishCode(''); setVehicleBrand('');
      }
    } else {
      // Reset form for new product
      setName('');
      setCategory(allCategories[0] || ProductCategory.ELECTRONICS);
      setPrice(0);
      setStock(0);
      setDescription('');
      setImageUrl('');
      setSpecificationsString('{}');
      setOem(''); setFinishCode(''); setVehicleBrand('');
    }
    setFormError(null);
  }, [existingProduct, isOpen, allCategories]);

  const handleSpecificationsChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const str = e.target.value;
    setSpecificationsString(str);
    try {
      const parsed = JSON.parse(str);
      if (typeof parsed === 'object' && !Array.isArray(parsed) && parsed !== null) {
        setFormError(null);
      } else {
        throw new Error("JSON nesne olmalıdır.");
      }
    } catch (err) {
      setFormError("Özellikler geçerli bir JSON formatında olmalıdır (örn: {\"Renk\":\"Mavi\"}).");
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (price < 0 || stock < 0) {
      setFormError("Fiyat ve stok negatif olamaz.");
      return;
    }

    let finalSpecifications: Record<string, string> = {};

    if (category === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
      if (!oem || !finishCode || !vehicleBrand || !description ) { // Açıklama (isim) otomotiv için zorunlu
        setFormError("Otomotiv parçası için Oem, Finish Kodu, Açıklama (İsim) ve Araç Markası alanları zorunludur.");
        return;
      }
      finalSpecifications = {
        "Oem": oem,
        "Finish Kodu": finishCode,
        "Araç Markası": vehicleBrand,
      };
       // Kullanıcı yine de genel specifications alanına bir şeyler yazdıysa onu da ekleyebiliriz.
      try {
        const generalSpecs = JSON.parse(specificationsString || '{}');
        if (typeof generalSpecs === 'object' && !Array.isArray(generalSpecs) && generalSpecs !== null) {
            finalSpecifications = {...finalSpecifications, ...generalSpecs};
        }
      } catch (e) { /* no-op, JSON parse hatası zaten formda gösterilir */ }

    } else { // Genel Kategoriler
      try {
        const parsedSpecs = JSON.parse(specificationsString || '{}');
        if (typeof parsedSpecs === 'object' && !Array.isArray(parsedSpecs) && parsedSpecs !== null) {
          finalSpecifications = parsedSpecs;
        } else {
          setFormError("Genel Özellikler geçerli bir JSON nesnesi olmalıdır.");
          return;
        }
      } catch (err) {
        setFormError("Genel Özellikler alanında geçersiz JSON formatı.");
        return;
      }
    }
    
    // Otomotivde 'description' aslında 'name' olarak kullanılıyordu, 'description' alanı da aynı veya YZ ile.
    // Bu formda 'name' ve 'description' ayrı.
    const productData = {
      name: category === ProductCategory.OTOMOTIV_YEDEK_PARCA ? description : name, // Otomotivde description'ı name olarak kullan
      category,
      price,
      stock,
      description: description, // Her durumda description'ı sakla
      imageUrl,
      specifications: finalSpecifications,
    };

    if (existingProduct) {
      onSubmit({ ...existingProduct, ...productData });
    } else {
      onSubmit(productData);
    }
  };

  const handleGenerateDescription = async () => {
    const productNameForAI = category === ProductCategory.OTOMOTIV_YEDEK_PARCA ? (vehicleBrand + " " + (oem || '') + " Yedek Parça") : name;
    if (!productNameForAI || !category) {
      alert("Lütfen önce ürün adı/detayları ve kategori girin.");
      return;
    }
    setIsAiLoading(true);
    try {
      const desc = await generateProductDescription(productNameForAI, category);
      setDescription(desc);
    } catch (err) {
      console.error("YZ Açıklama üretme hatası:", err);
      alert("Açıklama üretilirken bir hata oluştu.");
    }
    setIsAiLoading(false);
  };

  const handleGenerateImageUrl = async () => {
    const productNameForAI = category === ProductCategory.OTOMOTIV_YEDEK_PARCA ? (vehicleBrand + " " + (oem || '') + " Yedek Parça") : name;
    if (!productNameForAI || !category) {
      alert("Lütfen önce ürün adı/detayları ve kategori girin.");
      return;
    }
    setIsAiLoading(true);
    try {
      const url = await generateProductImageUrl(productNameForAI, category);
      setImageUrl(url);
    } catch (err) {
      console.error("YZ Resim URL üretme hatası:", err);
      alert("Resim URL'si üretilirken bir hata oluştu.");
    }
    setIsAiLoading(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[80] p-4">
      <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
        <h2 className="text-2xl font-semibold mb-6 text-slate-700">
          {existingProduct ? 'Ürünü Düzenle' : 'Yeni Ürün Ekle'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          
          <div>
            <label htmlFor="productCategory" className="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
            <select id="productCategory" value={category} 
              onChange={e => {
                setCategory(e.target.value as ProductCategory);
                // Kategori değiştiğinde otomotiv özel alanlarını ve genel özellikleri sıfırla/ayarla
                if (e.target.value !== ProductCategory.OTOMOTIV_YEDEK_PARCA) {
                    setOem(''); setFinishCode(''); setVehicleBrand('');
                } else {
                    setSpecificationsString('{}'); // Otomotiv seçilince genel JSON'u boşalt
                }
              }} 
              required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
            >
              {allCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>

          {category === ProductCategory.OTOMOTIV_YEDEK_PARCA ? (
            <>
              <div>
                <label htmlFor="productDescriptionAutomotive" className="block text-sm font-medium text-gray-700 mb-1">Açıklama (Ürün Adı olarak da kullanılır) <span className="text-red-500">*</span></label>
                <input type="text" id="productDescriptionAutomotive" value={description} onChange={e => setDescription(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
              </div>
              <div>
                <label htmlFor="vehicleBrand" className="block text-sm font-medium text-gray-700 mb-1">Araç Markası <span className="text-red-500">*</span></label>
                <input type="text" id="vehicleBrand" value={vehicleBrand} onChange={e => setVehicleBrand(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
              </div>
              <div>
                <label htmlFor="oem" className="block text-sm font-medium text-gray-700 mb-1">Oem <span className="text-red-500">*</span></label>
                <input type="text" id="oem" value={oem} onChange={e => setOem(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
              </div>
              <div>
                <label htmlFor="finishCode" className="block text-sm font-medium text-gray-700 mb-1">Finish Kodu <span className="text-red-500">*</span></label>
                <input type="text" id="finishCode" value={finishCode} onChange={e => setFinishCode(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
              </div>
            </>
          ) : (
            <div>
              <label htmlFor="productName" className="block text-sm font-medium text-gray-700 mb-1">Ürün Adı <span className="text-red-500">*</span></label>
              <input type="text" id="productName" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
          )}


          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="productPrice" className="block text-sm font-medium text-gray-700 mb-1">Fiyat ($) <span className="text-red-500">*</span></label>
              <input type="number" id="productPrice" value={price} onChange={e => setPrice(parseFloat(e.target.value) || 0)} required min="0" step="0.01" className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
            <div>
              <label htmlFor="productStock" className="block text-sm font-medium text-gray-700 mb-1">Stok Adedi <span className="text-red-500">*</span></label>
              <input type="number" id="productStock" value={stock} onChange={e => setStock(parseInt(e.target.value) || 0)} required min="0" className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
          </div>
          
          {category !== ProductCategory.OTOMOTIV_YEDEK_PARCA && (
            <div>
                <label htmlFor="productDescriptionGeneral" className="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                <textarea id="productDescriptionGeneral" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
                <button type="button" onClick={handleGenerateDescription} disabled={isAiLoading || !name || !category} className="mt-1 text-xs bg-orange-100 hover:bg-orange-200 text-orange-700 py-1 px-2 rounded-md disabled:opacity-50">
                {isAiLoading ? <LoadingSpinner size="sm" /> : 'YZ ile Açıklama Öner'}
                </button>
            </div>
          )}


          <div>
            <label htmlFor="productImageUrl" className="block text-sm font-medium text-gray-700 mb-1">Resim URL'si</label>
            <input type="url" id="productImageUrl" value={imageUrl} onChange={e => setImageUrl(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
             <button type="button" onClick={handleGenerateImageUrl} disabled={isAiLoading || (!name && category !== ProductCategory.OTOMOTIV_YEDEK_PARCA) || (!vehicleBrand && category === ProductCategory.OTOMOTIV_YEDEK_PARCA) || !category} className="mt-1 text-xs bg-orange-100 hover:bg-orange-200 text-orange-700 py-1 px-2 rounded-md disabled:opacity-50">
              {isAiLoading ? <LoadingSpinner size="sm" /> : 'YZ ile Placeholder Resim Öner'}
            </button>
          </div>

          {category !== ProductCategory.OTOMOTIV_YEDEK_PARCA && (
            <div>
                <label htmlFor="productSpecifications" className="block text-sm font-medium text-gray-700 mb-1">Genel Özellikler (JSON Formatında)</label>
                <textarea 
                    id="productSpecifications" 
                    value={specificationsString} 
                    onChange={handleSpecificationsChange} 
                    rows={4} 
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500 font-mono text-sm" 
                    placeholder='Örn: {"Renk": "Kırmızı", "Malzeme": "Pamuk"}' 
                />
                <p className="text-xs text-gray-500 mt-1">Geçerli bir JSON nesnesi girin. Örneğin: <code>{"{\"Ağırlık\":\"1kg\", \"Boyut\":\"10x20cm\"}"}</code></p>
            </div>
          )}
           {category === ProductCategory.OTOMOTIV_YEDEK_PARCA && (
             <p className="text-xs text-gray-500 mt-1 mb-2">Otomotiv parçası için ek genel özellikler (JSON formatında) girmek isterseniz aşağıdaki alanı kullanabilirsiniz. Bu, Oem, Finish Kodu gibi özel alanlara ek olarak kaydedilecektir.</p>
           )}
            {category === ProductCategory.OTOMOTIV_YEDEK_PARCA && ( // Otomotiv için de genel JSON alanı, ek bilgiler için.
                <div>
                    <label htmlFor="productSpecificationsAutomotiveExtra" className="block text-sm font-medium text-gray-700 mb-1">Ek Özellikler (JSON - Opsiyonel)</label>
                    <textarea 
                        id="productSpecificationsAutomotiveExtra" 
                        value={specificationsString} // Bu hala genel JSON'u tutar
                        onChange={handleSpecificationsChange} 
                        rows={3} 
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500 font-mono text-sm" 
                        placeholder='Örn: {"Garanti":"2 Yıl"}' 
                    />
                </div>
            )}


          {formError && <p className="text-red-500 text-sm mt-2">{formError}</p>}

          <div className="flex justify-end space-x-3 pt-4 border-t mt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md border border-gray-300"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={isAiLoading}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50"
            >
              {isAiLoading ? <LoadingSpinner size="sm" color="text-white"/> : (existingProduct ? 'Güncelle' : 'Oluştur')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProductFormModal;