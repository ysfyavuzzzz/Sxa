
import React, { useState, useCallback, useEffect } from 'react';
import { Product, ProductCategory, User } from '../types';
import { generateProductDescription, generateProductImageUrl } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import ProductFormModal from './ProductFormModal'; 

interface ProductManagementPageProps {
  products: Product[]; 
  onCreateSingleProduct: (newProductData: Omit<Product, 'id' | 'isTrashed'>) => void;
  onUpdateProduct: (updatedProductData: Product) => void;
  onSoftDeleteProduct: (productId: string) => void;
  onAddMultipleProducts: (products: Product[]) => void;
  allCategories: ProductCategory[];
  onNavigateToCatalog: () => void;
  currentUser: User;
}

interface PreviewProduct extends Partial<Product> {
  originalName?: string;
  originalDescription?: string;
  originalImageUrl?: string;
  aiSuggestedDescription?: string;
  aiSuggestedImageUrl?: string;
  parseError?: string;
  // Zorunlu alanlar PreviewProduct için
  name: string; // Genel için name, Otomotiv için description'dan gelebilir
  category: ProductCategory;
  price: number;
  stock: number; // Otomotiv için CSV'de opsiyonel, varsayılan 0 atanacak
  // Otomotive özel alanlar
  oem?: string;
  finish_code?: string;
  vehicle_brand?: string;
  // description alanı zaten Product'ta var, Otomotiv'de CSV'den gelen description hem name hem desc olacak
}

type ViewMode = 'bulk_import' | 'manage_existing';

const GENERIC_CATEGORY_VALUE = "GENEL"; // Genel CSV şablonu için bir değer

const ProductManagementPage: React.FC<ProductManagementPageProps> = ({ 
    products,
    onCreateSingleProduct,
    onUpdateProduct,
    onSoftDeleteProduct,
    onAddMultipleProducts, 
    allCategories, 
    onNavigateToCatalog,
    currentUser 
}) => {
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [previewProducts, setPreviewProducts] = useState<PreviewProduct[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [parsingProgress, setParsingProgress] = useState(0);
  const [viewMode, setViewMode] = useState<ViewMode>('bulk_import'); 
  const [targetImportCategory, setTargetImportCategory] = useState<ProductCategory | typeof GENERIC_CATEGORY_VALUE>(GENERIC_CATEGORY_VALUE);


  const [isProductFormModalOpen, setIsProductFormModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);


  const openCreateProductModal = () => {
    setEditingProduct(null);
    setIsProductFormModalOpen(true);
  };

  const openEditProductModal = (product: Product) => {
    setEditingProduct(product);
    setIsProductFormModalOpen(true);
  };

  const handleProductFormSubmit = (productData: Omit<Product, 'id' | 'isTrashed'> | Product) => {
    if ('id' in productData) { 
        onUpdateProduct(productData as Product);
    } else { 
        onCreateSingleProduct(productData as Omit<Product, 'id' | 'isTrashed'>);
    }
    setIsProductFormModalOpen(false);
    setEditingProduct(null);
  };


  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === "text/csv") {
      setCsvFile(file);
      setError(null);
      setPreviewProducts([]);
    } else {
      setCsvFile(null);
      setError("Lütfen geçerli bir CSV dosyası seçin.");
      setPreviewProducts([]);
    }
  };

  const parseCSV = async (file: File, importCategory: ProductCategory | typeof GENERIC_CATEGORY_VALUE): Promise<PreviewProduct[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (!text) {
          reject(new Error("Dosya içeriği okunamadı."));
          return;
        }
        const lines = text.split(/\r\n|\n/).filter(line => line.trim() !== '');
        if (lines.length < 2) {
          reject(new Error("CSV dosyasında başlık satırı ve en az bir veri satırı bulunmalıdır."));
          return;
        }

        const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/\s+/g, '_')); // Boşlukları _ ile değiştir
        const parsedCsvProducts: PreviewProduct[] = [];

        for (let i = 1; i < lines.length; i++) {
          const values = lines[i].split(',');
          const rowData: any = {};
          headers.forEach((header, index) => {
            rowData[header] = values[index]?.trim() || '';
          });

          let productEntry: Partial<PreviewProduct> = {};
          let parseErrorMsg: string | undefined;

          if (importCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
            const requiredAutomotiveHeaders = ['oem', 'finish_kodu', 'açıklama', 'araç_markası', 'fiyat'];
            const missingAutomotiveHeaders = requiredAutomotiveHeaders.filter(rh => !rowData[rh]);

            if (missingAutomotiveHeaders.length > 0) {
              parseErrorMsg = `Satır ${i + 1} (Otomotiv): Eksik zorunlu alanlar: ${missingAutomotiveHeaders.join(', ')}.`;
            } else {
              productEntry = {
                name: rowData['açıklama'], // 'açıklama'yı 'name' olarak kullan
                category: ProductCategory.OTOMOTIV_YEDEK_PARCA,
                price: parseFloat(rowData['fiyat']),
                stock: parseInt(rowData['stok'] || '0'), // Stok yoksa 0
                description: rowData['açıklama'], // 'açıklama'yı 'description' olarak da kullan
                imageUrl: rowData['resim'] || undefined,
                specifications: {
                  "Oem": rowData['oem'],
                  "Finish Kodu": rowData['finish_kodu'],
                  "Araç Markası": rowData['araç_markası'],
                },
                oem: rowData['oem'],
                finish_code: rowData['finish_kodu'],
                vehicle_brand: rowData['araç_markası'],
              };
            }
          } else { // Genel Kategori
            const requiredGenericHeaders = ['name', 'category', 'price', 'stock'];
            const missingGenericHeaders = requiredGenericHeaders.filter(rh => !rowData[rh]);
            
            const categoryValue = Object.values(ProductCategory).find(
              (catEnum) => catEnum.toLowerCase() === rowData.category?.toLowerCase()
            ) as ProductCategory | undefined;

            if (missingGenericHeaders.length > 0 || !categoryValue) {
              parseErrorMsg = `Satır ${i + 1} (Genel): Eksik veya geçersiz zorunlu alanlar (name, category, price, stock). Kategori bulunamadı: ${rowData.category}.`;
            } else {
                let specificationsParsed: Record<string, string> | undefined = undefined;
                if (rowData.specifications) {
                    try {
                        specificationsParsed = JSON.parse(rowData.specifications);
                    } catch (e) {
                        parseErrorMsg = `Satır ${i+1} (Genel): 'specifications' geçerli JSON formatında değil. "${rowData.specifications}"`;
                    }
                }
                 if (!parseErrorMsg) {
                    productEntry = {
                        id: rowData.id || undefined,
                        name: rowData.name,
                        category: categoryValue,
                        price: parseFloat(rowData.price),
                        stock: parseInt(rowData.stock),
                        description: rowData.description || undefined,
                        imageUrl: rowData.imageurl || rowData.imageUrl || undefined,
                        specifications: specificationsParsed,
                    };
                 }
            }
          }
          
          // Ortak hata kontrolü ve ekleme
          if (parseErrorMsg || !productEntry.name || productEntry.category === undefined || isNaN(productEntry.price ?? NaN) || isNaN(productEntry.stock ?? NaN) ) {
             parsedCsvProducts.push({
                name: rowData.name || rowData['açıklama'] || `Satır ${i+1} Ürünü`,
                category: productEntry.category || (importCategory !== GENERIC_CATEGORY_VALUE ? importCategory : ProductCategory.ELECTRONICS),
                price: productEntry.price || 0,
                stock: productEntry.stock || 0,
                description: productEntry.description,
                imageUrl: productEntry.imageUrl,
                specifications: productEntry.specifications,
                oem: productEntry.oem,
                finish_code: productEntry.finish_code,
                vehicle_brand: productEntry.vehicle_brand,
                parseError: parseErrorMsg || `Satır ${i+1}: Genel veri hatası.`,
              });
          } else {
            parsedCsvProducts.push({
                ...productEntry,
                originalName: productEntry.name,
                originalDescription: productEntry.description,
                originalImageUrl: productEntry.imageUrl,
            } as PreviewProduct);
          }
        }
        resolve(parsedCsvProducts);
      };
      reader.onerror = () => reject(new Error("Dosya okunurken hata oluştu."));
      reader.readAsText(file, 'UTF-8'); // UTF-8 olarak oku
    });
  };
  

  const processProductsWithAI = async (parsedProducts: PreviewProduct[], importCategory: ProductCategory | typeof GENERIC_CATEGORY_VALUE) => {
    setIsLoading(true);
    setParsingProgress(0);
    const processed: PreviewProduct[] = [];
    for (let i = 0; i < parsedProducts.length; i++) {
      const product = parsedProducts[i];
       if (product.parseError) {
        processed.push(product);
        setParsingProgress(((i + 1) / parsedProducts.length) * 100);
        continue;
      }

      let aiDescription = product.description;
      // Otomotivde 'açıklama' CSV'den geliyor ve name için kullanılıyor, AI desc için ayrıca çalıştırılabilir veya aynı kalabilir.
      // Genel kategoride eğer description boşsa AI çalışır.
      if (importCategory === GENERIC_CATEGORY_VALUE && !product.description && product.name && product.category) {
        aiDescription = await generateProductDescription(product.name, product.category);
      } else if (importCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA && product.name && product.category) {
        // Otomotiv için YZ'den açıklama almayı (CSV'deki zaten name oldu) isteğe bağlı yapabiliriz.
        // Şimdilik CSV'deki açıklamayı kullanıyoruz.
        // aiDescription = await generateProductDescription(product.name, product.category); 
      }


      let aiImageUrl = product.imageUrl;
      if (!product.imageUrl && product.name && product.category) {
        aiImageUrl = await generateProductImageUrl(product.name, product.category);
      }
      
      processed.push({
        ...product,
        description: aiDescription || product.description, 
        imageUrl: aiImageUrl || product.imageUrl,
        aiSuggestedDescription: (aiDescription && aiDescription !== product.description) ? aiDescription : undefined,
        aiSuggestedImageUrl: (aiImageUrl && aiImageUrl !== product.imageUrl) ? aiImageUrl : undefined,
      });
      setParsingProgress(((i + 1) / parsedProducts.length) * 100);
    }
    setIsLoading(false);
    return processed;
  };


  const handleProcessFile = async () => {
    if (!csvFile) {
      setError("Lütfen önce bir CSV dosyası seçin.");
      return;
    }
    setError(null);
    setIsLoading(true);
    setPreviewProducts([]);

    try {
      const parsed = await parseCSV(csvFile, targetImportCategory);
      const productsWithAI = await processProductsWithAI(parsed, targetImportCategory);
      setPreviewProducts(productsWithAI);
    } catch (e: any) {
      setError(e.message || "Dosya işlenirken bir hata oluştu.");
      setPreviewProducts([]);
    } finally {
      setIsLoading(false);
      setParsingProgress(0);
    }
  };

  const handlePreviewChange = (index: number, field: keyof PreviewProduct, value: any) => {
    setPreviewProducts(prev => 
      prev.map((p, i) => {
        if (i === index) {
          const updatedProduct = { ...p, [field]: value };
          // Eğer otomotiv ise ve özel alanlar güncelleniyorsa specifications'ı da güncelle
          if (targetImportCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
            if (field === 'oem' || field === 'finish_code' || field === 'vehicle_brand') {
              updatedProduct.specifications = {
                ...updatedProduct.specifications,
                "Oem": field === 'oem' ? value : updatedProduct.oem,
                "Finish Kodu": field === 'finish_code' ? value : updatedProduct.finish_code,
                "Araç Markası": field === 'vehicle_brand' ? value : updatedProduct.vehicle_brand,
              };
            }
            if (field === 'description') { // Otomotivde description aynı zamanda name
                updatedProduct.name = value;
            }
          }
          return updatedProduct;
        }
        return p;
      })
    );
  };
  

  const handleConfirmImport = () => {
    if (previewProducts.some(p => p.parseError)) {
        if (!window.confirm("Bazı ürünlerde ayrıştırma hataları var. Yine de devam etmek istiyor musunuz? Sadece hatasız ürünler eklenecektir.")) {
            return;
        }
    }
    const validProducts = previewProducts
        .filter(p => !p.parseError)
        .map(p => {
            const baseProduct = {
                id: p.id || `prod-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                name: p.name, // name her zaman dolu olmalı (otomotivde description'dan geliyor)
                category: p.category,
                price: p.price,
                description: p.description || p.name, // Açıklama yoksa adı kullan
                imageUrl: p.imageUrl || 'https://picsum.photos/seed/defaultproduct/600/400', 
                stock: p.stock, // stok her zaman dolu olmalı
                isTrashed: false,
            };

            if (targetImportCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
                return {
                    ...baseProduct,
                    specifications: {
                        "Oem": p.oem || '',
                        "Finish Kodu": p.finish_code || '',
                        "Araç Markası": p.vehicle_brand || '',
                         // Kullanıcı önizlemede specifications'ı JSON olarak düzenlediyse onu da ekleyelim.
                        ...(typeof p.specifications === 'object' ? p.specifications : {}),
                    }
                };
            } else { // Genel Kategori
                 return {
                    ...baseProduct,
                    specifications: typeof p.specifications === 'string' 
                        ? JSON.parse(p.specifications || '{}') // Kullanıcı string olarak düzenlediyse parse et
                        : (p.specifications || {}), // Yoksa nesne olarak al veya boş nesne
                };
            }
    });

    if (validProducts.length === 0) {
        alert("Eklenecek geçerli ürün bulunamadı.");
        return;
    }
    onAddMultipleProducts(validProducts as Product[]);
    setPreviewProducts([]);
    setCsvFile(null);
  };

  const getCsvInstructions = () => {
    if (targetImportCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
      return (
        <>
          <h3 className="font-semibold mb-2">"Otomotiv Yedek Parça" CSV Formatı:</h3>
          <ul className="list-disc list-inside space-y-1">
            <li>Başlıklar (sırası önemli değil, küçük/büyük harf duyarsız, boşluklar alt çizgiye dönüşür): <code>Oem, Finish Kodu, Açıklama, Araç Markası, Fiyat, Stok (opsiyonel), Resim (opsiyonel)</code>.</li>
            <li>Zorunlu Alanlar: <code>Oem, Finish Kodu, Açıklama, Araç Markası, Fiyat</code>.</li>
            <li><code>Açıklama</code>: Ürünün adı ve açıklaması olarak kullanılacaktır.</li>
            <li><code>Stok</code>: Belirtilmezse varsayılan olarak 0 kabul edilir.</li>
            <li><code>Resim</code>: Resim URL'si. Boş bırakılırsa YZ placeholder üretebilir.</li>
          </ul>
        </>
      );
    }
    // Genel Kategori Talimatları
    return (
      <>
        <h3 className="font-semibold mb-2">Genel CSV Dosya Formatı Talimatları:</h3>
        <ul className="list-disc list-inside space-y-1">
          <li>Dosya UTF-8 formatında olmalıdır.</li>
          <li>İlk satır başlık satırı olmalıdır. Başlıklar (normalleştirilmiş): <code>name,category,price,stock,description,imageUrl,specifications,id</code> (id opsiyoneldir).</li>
          <li>Zorunlu alanlar: <code>name</code>, <code>category</code>, <code>price</code>, <code>stock</code>.</li>
          <li><code>category</code>: Sistemde tanımlı kategorilerden biri olmalıdır.</li>
          <li><code>description</code>: Boş bırakılırsa YZ tarafından oluşturulmaya çalışılır.</li>
          <li><code>imageUrl</code>: Boş bırakılırsa YZ tarafından placeholder bir URL oluşturulmaya çalışılır.</li>
          <li><code>specifications</code>: JSON formatında bir string olmalıdır (örn: <code>"{""Renk"":""Kırmızı"",""Boyut"":""XL""}"</code>).</li>
        </ul>
      </>
    );
  };
  
  const renderPreviewTableHeaders = () => {
    if (targetImportCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
      return ['Oem', 'Finish Kodu', 'Açıklama (Ad)', 'Araç Markası', 'Fiyat', 'Stok', 'Resim URL', 'Hata'].map(header => (
        <th key={header} scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">{header}</th>
      ));
    }
    return ['Ad', 'Kategori', 'Fiyat', 'Stok', 'Açıklama', 'Resim URL', 'Özellikler (JSON)', 'Hata'].map(header => (
      <th key={header} scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">{header}</th>
    ));
  };

  const renderPreviewTableRow = (p: PreviewProduct, index: number) => {
    if (targetImportCategory === ProductCategory.OTOMOTIV_YEDEK_PARCA) {
      return (
        <tr key={index} className={p.parseError ? 'bg-red-50' : ''}>
          <td className="px-3 py-2 whitespace-nowrap"><input type="text" value={p.oem || ''} onChange={e => handlePreviewChange(index, 'oem', e.target.value)} className="w-full p-1 border border-gray-300 rounded text-sm" /></td>
          <td className="px-3 py-2 whitespace-nowrap"><input type="text" value={p.finish_code || ''} onChange={e => handlePreviewChange(index, 'finish_code', e.target.value)} className="w-full p-1 border border-gray-300 rounded text-sm" /></td>
          <td className="px-3 py-2">
            <textarea value={p.description || ''} onChange={e => handlePreviewChange(index, 'description', e.target.value)} rows={2} className={`w-full p-1 border border-gray-300 rounded text-sm ${p.aiSuggestedDescription ? 'bg-yellow-100 border-yellow-400' : ''}`} title={p.aiSuggestedDescription ? `YZ Önerisi: ${p.aiSuggestedDescription}` : (p.description === p.name ? 'Açıklama (Ad ile aynı)' : '')} />
            {p.aiSuggestedDescription && <span className="text-xs text-yellow-600 block">YZ önerisi</span>}
          </td>
          <td className="px-3 py-2 whitespace-nowrap"><input type="text" value={p.vehicle_brand || ''} onChange={e => handlePreviewChange(index, 'vehicle_brand', e.target.value)} className="w-full p-1 border border-gray-300 rounded text-sm" /></td>
          <td className="px-3 py-2 whitespace-nowrap"><input type="number" value={p.price || 0} onChange={e => handlePreviewChange(index, 'price', parseFloat(e.target.value))} className="w-20 p-1 border border-gray-300 rounded text-sm" /></td>
          <td className="px-3 py-2 whitespace-nowrap"><input type="number" value={p.stock || 0} onChange={e => handlePreviewChange(index, 'stock', parseInt(e.target.value))} className="w-16 p-1 border border-gray-300 rounded text-sm" /></td>
          <td className="px-3 py-2">
            <input type="text" value={p.imageUrl || ''} onChange={e => handlePreviewChange(index, 'imageUrl', e.target.value)} className={`w-full p-1 border border-gray-300 rounded text-sm ${p.aiSuggestedImageUrl ? 'bg-yellow-100 border-yellow-400' : ''}`} title={p.aiSuggestedImageUrl ? `YZ Önerisi: ${p.aiSuggestedImageUrl}` : ''} />
            {p.aiSuggestedImageUrl && <span className="text-xs text-yellow-600 block">YZ placeholder</span>}
          </td>
          <td className="px-3 py-2 whitespace-nowrap text-xs text-red-500">{p.parseError}</td>
        </tr>
      );
    }
    // Genel kategori satırı
    return (
      <tr key={index} className={p.parseError ? 'bg-red-50' : ''}>
        <td className="px-3 py-2 whitespace-nowrap"><input type="text" value={p.name || ''} onChange={e => handlePreviewChange(index, 'name', e.target.value)} className="w-full p-1 border border-gray-300 rounded text-sm" /></td>
        <td className="px-3 py-2 whitespace-nowrap">
          <select value={p.category || ''} onChange={e => handlePreviewChange(index, 'category', e.target.value as ProductCategory)} className="w-full p-1 border border-gray-300 rounded text-sm">
            {allCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>
        </td>
        <td className="px-3 py-2 whitespace-nowrap"><input type="number" value={p.price || 0} onChange={e => handlePreviewChange(index, 'price', parseFloat(e.target.value))} className="w-20 p-1 border border-gray-300 rounded text-sm" /></td>
        <td className="px-3 py-2 whitespace-nowrap"><input type="number" value={p.stock || 0} onChange={e => handlePreviewChange(index, 'stock', parseInt(e.target.value))} className="w-16 p-1 border border-gray-300 rounded text-sm" /></td>
        <td className="px-3 py-2">
          <textarea value={p.description || ''} onChange={e => handlePreviewChange(index, 'description', e.target.value)} rows={2} className={`w-full p-1 border border-gray-300 rounded text-sm ${p.aiSuggestedDescription ? 'bg-yellow-100 border-yellow-400' : ''}`} title={p.aiSuggestedDescription ? `YZ Önerisi: ${p.aiSuggestedDescription}` : ''} />
          {p.aiSuggestedDescription && <span className="text-xs text-yellow-600 block">YZ önerisi</span>}
        </td>
        <td className="px-3 py-2">
          <input type="text" value={p.imageUrl || ''} onChange={e => handlePreviewChange(index, 'imageUrl', e.target.value)} className={`w-full p-1 border border-gray-300 rounded text-sm ${p.aiSuggestedImageUrl ? 'bg-yellow-100 border-yellow-400' : ''}`} title={p.aiSuggestedImageUrl ? `YZ Önerisi: ${p.aiSuggestedImageUrl}` : ''} />
          {p.aiSuggestedImageUrl && <span className="text-xs text-yellow-600 block">YZ placeholder</span>}
        </td>
        <td className="px-3 py-2"><textarea value={typeof p.specifications === 'string' ? p.specifications : JSON.stringify(p.specifications || {})} onChange={e => handlePreviewChange(index, 'specifications', e.target.value)} rows={2} className="w-full p-1 border border-gray-300 rounded text-sm" placeholder='{"Renk":"Mavi"}' /></td>
        <td className="px-3 py-2 whitespace-nowrap text-xs text-red-500">{p.parseError}</td>
      </tr>
    );
  };


  return (
    <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <h1 className="text-3xl font-bold text-slate-800 mb-4 sm:mb-0">
            Ürün Yönetimi
          </h1>
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
          >
            Kataloğa Dön
          </button>
        </div>

        <div className="mb-6 flex space-x-2 border-b pb-3">
          <button
            onClick={() => setViewMode('bulk_import')}
            className={`py-2 px-4 rounded-md font-medium transition-colors ${viewMode === 'bulk_import' ? 'bg-orange-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
          >
            Toplu Ürün Ekleme (CSV)
          </button>
          <button
            onClick={() => setViewMode('manage_existing')}
            className={`py-2 px-4 rounded-md font-medium transition-colors ${viewMode === 'manage_existing' ? 'bg-orange-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
          >
            Mevcut Ürünleri Yönet
          </button>
        </div>

        {viewMode === 'bulk_import' && (
          <>
            <div className="mb-4">
                <label htmlFor="targetImportCategory" className="block text-sm font-medium text-gray-700 mb-1">
                    CSV İçe Aktarma Kategorisi:
                </label>
                <select
                    id="targetImportCategory"
                    value={targetImportCategory}
                    onChange={(e) => {
                        setTargetImportCategory(e.target.value as ProductCategory | typeof GENERIC_CATEGORY_VALUE);
                        setCsvFile(null); // Kategori değişince seçili dosyayı ve önizlemeyi sıfırla
                        setPreviewProducts([]);
                        setError(null);
                    }}
                    className="w-full sm:w-auto p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                >
                    <option value={GENERIC_CATEGORY_VALUE}>Genel (Varsayılan Format)</option>
                    {allCategories.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                    ))}
                </select>
            </div>
            <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-md text-sm text-orange-700">
              {getCsvInstructions()}
            </div>

            <div className="mb-6">
              <label htmlFor="csvFile" className="block text-sm font-medium text-gray-700 mb-1">
                CSV Dosyası Seçin:
              </label>
              <input
                type="file"
                id="csvFile"
                accept=".csv"
                onChange={handleFileChange}
                className="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 file:mr-4 file:py-2 file:px-4 file:rounded-l-lg file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"
              />
            </div>

            {csvFile && (
              <button
                onClick={handleProcessFile}
                disabled={isLoading}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors disabled:opacity-50"
              >
                {isLoading ? 'Dosya İşleniyor...' : 'Dosyayı İşle ve Önizle'}
              </button>
            )}

            {isLoading && parsingProgress > 0 && (
                <div className="mt-4">
                    <div className="relative pt-1">
                        <div className="flex mb-2 items-center justify-between">
                            <div>
                                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-orange-600 bg-orange-200">
                                    Ürünler İşleniyor
                                </span>
                            </div>
                            <div className="text-right">
                                <span className="text-xs font-semibold inline-block text-orange-600">
                                    {Math.round(parsingProgress)}%
                                </span>
                            </div>
                        </div>
                        <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-orange-200">
                            <div style={{ width: `${parsingProgress}%` }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-orange-500 transition-all duration-300"></div>
                        </div>
                    </div>
                </div>
            )}
            {error && <p className="mt-4 text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}

            {previewProducts.length > 0 && !isLoading && (
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4 text-slate-700">Önizleme ve Düzenleme (CSV - {targetImportCategory})</h3>
                <p className="text-sm text-gray-600 mb-4">Aşağıdaki ürünler CSV dosyanızdan okundu. Gerekirse düzenlemeleri yapın. YZ tarafından önerilen alanlar vurgulanmıştır.</p>
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        {renderPreviewTableHeaders()}
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {previewProducts.map((p, index) => renderPreviewTableRow(p, index))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-6 flex justify-end">
                  <button
                    onClick={handleConfirmImport}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors"
                    disabled={previewProducts.filter(p => !p.parseError).length === 0}
                  >
                    CSV Ürünlerini Sisteme Ekle ({previewProducts.filter(p => !p.parseError).length})
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {viewMode === 'manage_existing' && (
          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-slate-700">Mevcut Ürünler</h3>
                <button
                    onClick={openCreateProductModal}
                    className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                >
                    Yeni Tekil Ürün Ekle
                </button>
            </div>
            {products.length === 0 ? (
                <p className="text-gray-600">Henüz hiç ürün eklenmemiş.</p>
            ) : (
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ad</th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kategori</th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fiyat</th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stok</th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {products.map(product => (
                                <tr key={product.id}>
                                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{product.name}</td>
                                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{product.category}</td>
                                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${product.price.toFixed(2)}</td>
                                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{product.stock}</td>
                                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium space-x-2">
                                        <button
                                            onClick={() => openEditProductModal(product)}
                                            className="text-orange-600 hover:text-orange-800"
                                        >
                                            Düzenle
                                        </button>
                                        <button
                                            onClick={() => {
                                                if (window.confirm(`'${product.name}' ürününü kaldırmak istediğinizden emin misiniz? Ürün çöp kutusuna taşınacaktır.`)) {
                                                    onSoftDeleteProduct(product.id);
                                                }
                                            }}
                                            className="text-amber-600 hover:text-amber-800"
                                        >
                                            Kaldır
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
          </div>
        )}
      </div>
       {isProductFormModalOpen && (
        <ProductFormModal
          isOpen={isProductFormModalOpen}
          onClose={() => setIsProductFormModalOpen(false)}
          onSubmit={handleProductFormSubmit}
          existingProduct={editingProduct}
          allCategories={allCategories}
        />
      )}
    </main>
  );
};

export default ProductManagementPage;