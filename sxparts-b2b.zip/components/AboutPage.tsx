
import React from 'react';

interface AboutPageProps {
  onNavigateToCatalog: () => void;
}

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="text-2xl font-semibold text-slate-700 mt-8 mb-4 pb-2 border-b border-slate-300">{children}</h2>
);

const SubSectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3 className="text-xl font-semibold text-orange-700 mt-6 mb-3">{children}</h3>
);

const ListItem: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <li className="mb-2 flex">
    <span className="text-orange-600 mr-2">&#10148;</span>
    <span className="text-gray-700 leading-relaxed">{children}</span>
  </li>
);

const AboutPage: React.FC<AboutPageProps> = ({ onNavigateToCatalog }) => {
  return (
    <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <h1 className="text-3xl font-bold text-slate-800 mb-4 sm:mb-0">
            Sistem Hakkında: B2B Ürün Kataloğu & YZ Asistanı
          </h1>
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 self-start sm:self-center"
            aria-label="Ürün kataloğuna geri dön"
          >
            Kataloğa Dön
          </button>
        </div>

        <p className="text-gray-700 leading-relaxed mb-6">
          Bu uygulama, B2B (İşletmeden İşletmeye) kullanıcılarının ürünleri interaktif bir şekilde keşfetmelerini, detaylı bilgi edinmelerini ve yapay zeka destekli bir asistan aracılığıyla kişiselleştirilmiş öneriler almalarını sağlayan modern bir ürün kataloğudur. Uygulama, yalnızca kimliği doğrulanmış kullanıcıların erişimine açıktır ve farklı kullanıcı rolleriyle gelişmiş yetkilendirme mekanizmalarına sahiptir. Temel amacımız, B2B alışveriş deneyimini basitleştirmek, verimliliği artırmak ve kullanıcıların doğru ürünleri kolayca bulmalarına yardımcı olmaktır.
        </p>

        <SectionTitle>Kullanıcı Yönetimi ve Kimlik Doğrulama</SectionTitle>
        <ul className="list-none pl-0">
          <ListItem><strong>Zorunlu Kullanıcı Girişi:</strong> Sistem, içeriğe erişimden önce kullanıcıların kimlik doğrulaması yapmasını gerektiren bir giriş sayfasıyla başlar.</ListItem>
          <ListItem>
            <strong>Üyelik Sistemi:</strong> Uygulamamız, herkese açık bir platform değildir. Yeni kullanıcılar sadece yönetici tarafından doğrudan sisteme eklenebilir veya kayıt talepleri yönetici tarafından manuel olarak onaylanarak üye olabilirler. Bu, platformumuzun seçkin bir müşteri kitlesine özel olarak hizmet verdiğini ve üyeliklerin titizlikle değerlendirildiğini göstermektedir. Kayıt talebi oluşturan kullanıcılar, taleplerinin alındığı ve 24 saat içinde inceleneceği konusunda (simüle edilmiş) e-posta ve SMS ile bilgilendirilir.
          </ListItem>
          <ListItem>
            <strong>Kullanıcı Rolleri ve Yetkiler:</strong>
            <ul className="list-none pl-5 mt-2 space-y-1">
              <li><strong>Süper Admin (Arka Kapı):</strong>
                <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Sistemin en yetkili kullanıcısı. Tüm ürünleri yönetir, çöp kutusunu yönetir.</li>
                    <li>**Kullanıcı Yönetim Paneli'ne** tam erişim: Kullanıcı oluşturabilir, düzenleyebilir (rol, e-posta, isim, şifre, iskonto oranı, kategori erişimi, aktif/pasif durumu, yönetici yetkileri), bekleyen üyelik taleplerini onaylayabilir.</li>
                    <li>Yöneticilere özel yetkiler atayabilir: İskonto belirleyebilme, yeni üyelik açabilme, ürün yönetimi (kaldırma, toplu ekleme, tekil ekleme/düzenleme).</li>
                    <li>Tüm siparişleri görüntüleyebilir ("Siparişler" sayfasından) ve sipariş detaylarına erişebilir.</li>
                    <li>Kendini pasif yapamaz veya rolünü değiştiremez.</li>
                    <li>Tüm ürün kategorilerine erişebilir ve en yüksek iskonto oranına sahip olabilir.</li>
                    <li>"Ürün Yönetimi" sayfasına (toplu ve tekil ürün işlemleri) erişebilir.</li>
                </ul>
              </li>
              <li><strong>Yönetici (Müdür/Sistem Görevlisi):</strong>
                 <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Günlük operasyonel ürün yönetimi (eğer Süper Admin tarafından `canManageAllProducts` yetkisi verilmişse): Ürünleri katalogdan "kaldırabilir" (çöpe taşır), "Ürün Yönetimi" sayfasına erişerek ürün ekleyebilir/düzenleyebilir.</li>
                    <li>Diğer kullanıcılara iskonto atayabilir (eğer Süper Admin tarafından `canSetUserDiscounts` yetkisi verilmişse).</li>
                    <li>Yeni 'Müşteri Kullanıcısı' rolünde üyelikler açabilir (eğer Süper Admin tarafından `canCreateNewUsers` yetkisi verilmişse).</li>
                    <li>Bekleyen üyelik taleplerini onaylayabilir.</li>
                    <li>Tüm siparişleri görüntüleyebilir ("Siparişler" sayfasından) ve sipariş detaylarına erişebilir.</li>
                    <li>Tüm ürün kategorilerine erişebilir. Kendine özel iskonto oranı olabilir.</li>
                    <li>Kullanıcı yönetimi panelinin diğer kısımlarına ve çöp kutusuna erişemez. (Süper Admin izin verirse 'Müşteri Kullanıcısı' ekleyebilir/düzenleyebilir.)</li>
                </ul>
              </li>
              <li><strong>Müşteri Kullanıcısı (Rol: 'user'):</strong>
                 <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Sadece Süper Admin (veya yetkili Yönetici) tarafından kendisine atanmış ürün kategorilerini görebilir.</li>
                    <li>Sadece kendi siparişlerini görüntüleyebilir ("Siparişlerim" sayfasından) ve sipariş detaylarına erişebilir.</li>
                    <li>Kendine özel iskonto oranı olabilir.</li>
                    <li>Ürünleri görüntüleyebilir, sepete ekleyebilir ve YZ asistanı ile etkileşim kurabilir.</li>
                 </ul>
              </li>
            </ul>
          </ListItem>
          <ListItem><strong>Kullanıcı Yönetim Paneli:</strong> Süper Admin ve Yöneticiler, yetkileri dahilinde kullanıcıları yönetebilir ve bekleyen üyelik taleplerini onaylayabilir.</ListItem>
          <ListItem><strong>İskonto Oranları:</strong> Her kullanıcıya özel bir iskonto oranı tanımlanabilir. Bu oran, ürün fiyatlarına ve sepete otomatik olarak yansıtılır. Süper Admin veya `canSetUserDiscounts` yetkisine sahip Yöneticiler bu oranları ayarlayabilir.</ListItem>
          <ListItem><strong>Kategori Bazlı Ürün Erişimi:</strong> 'Müşteri Kullanıcısı' rolündeki müşteriler, sadece kendilerine atanan ürün kategorilerini görüntüleyebilir.</ListItem>
          <ListItem><strong>Hesap Aktivasyonu ve Onayı:</strong> Süper Admin veya Yönetici, kullanıcı hesaplarını aktif veya pasif hale getirebilir ve yeni üyelik taleplerini onaylayarak hesapları aktif edebilir.</ListItem>
          <ListItem><strong>Ön Tanımlı Hesaplar:</strong> Geliştirme için bir "Süper Admin" ve bir "Yönetici" hesabı bulunur.</ListItem>
        </ul>
        
        <SectionTitle>Ürün Yönetimi ve Katalog Özellikleri</SectionTitle>
        <ul className="list-none pl-0">
            <ListItem><strong>Dinamik Ürün Listeleme:</strong> Ürünler, kullanıcının erişim yetkilerine ve kategori atamalarına göre listelenir. İskonto oranları anında fiyatlara yansıtılır.</ListItem>
             <ListItem><strong>Adet Seçimiyle Sepete Ekleme:</strong> Kullanıcılar, ürün kartları üzerinden istedikleri adedi belirleyerek ürünleri sepetlerine ekleyebilirler. Stok durumu kontrol edilir.</ListItem>
            <ListItem>
                <strong>Geçici Silme (Soft Delete):</strong> Yetkili kullanıcılar (Süper Admin veya `canManageAllProducts` yetkisine sahip Yönetici) bir ürünü "kaldırdığında", ürün `isTrashed = true` olarak işaretlenir ve "Çöp Kutusu"na taşınır.
            </ListItem>
            <ListItem>
                <strong>Çöp Kutusu Yönetimi (Sadece Süper Admin):</strong> Süper Admin, çöpe atılan ürünleri geri yükleyebilir veya kalıcı olarak silebilir.
            </ListItem>
             <ListItem><strong>Gelişmiş Filtreleme ve Arama:</strong> Kullanıcılar, erişebildikleri kategorilere göre filtreleme yapabilir ve anahtar kelime ile arama yapabilir.</ListItem>
             <ListItem><strong>Detaylı Ürün Bilgisi:</strong> Genişletilebilir ürün kartları ile tüm özellikler ve stok durumu görülebilir.</ListItem>
             <ListItem>
                <strong>Kapsamlı Ürün Yönetim Sayfası:</strong> Yetkili kullanıcılar (Süper Admin veya `canManageAllProducts` yetkisine sahip Yönetici), "Ürün Yönetimi" sayfası üzerinden:
                <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Hedef kategori seçerek (örn: "Genel" veya "Otomotiv Yedek Parça") CSV formatında ürünleri toplu olarak sisteme yükleyebilir. Her kategori için farklı CSV şablonu ve zorunlu alanlar geçerli olabilir.</li>
                    <li><strong>Otomotiv Yedek Parça CSV Formatı:</strong> `Oem, Finish Kodu, Açıklama, Araç Markası, Fiyat` zorunlu; `Resim, Stok` opsiyoneldir. `Açıklama` sütunu ürün adı olarak kullanılır. Stok belirtilmezse 0 kabul edilir.</li>
                    <li>Eksik ürün açıklamaları veya resim URL'leri için YZ asistanı (Gemini API) önerilerde bulunabilir.</li>
                    <li>Yönetici, bu önerileri ve diğer ürün bilgilerini CSV yükleme sırasında son kez kontrol edip düzenleyebilir.</li>
                    <li>Mevcut ürünleri listeleyebilir, arayabilir ve filtreleyebilir.</li>
                    <li>Tekil olarak yeni ürün ekleyebilir veya mevcut ürünleri detaylı bir şekilde düzenleyebilir. Kategori seçimine göre formda gösterilen alanlar değişebilir (örn: "Otomotiv Yedek Parça" seçildiğinde Oem, Finish Kodu gibi özel alanlar görünür).</li>
                    <li>Ürünleri katalogdan kaldırabilir (çöpe taşıyabilir).</li>
                </ul>
            </ListItem>
        </ul>

        <SectionTitle>Alışveriş Sepeti Özelliği</SectionTitle>
        <ul className="list-none pl-0">
            <ListItem><strong>Ürün Ekleme:</strong> Kullanıcılar, ürün kartlarındaki "Sepete Ekle" butonu ve adet kontrolleri ile istedikleri ürünleri sepetlerine ekleyebilirler.</ListItem>
            <ListItem><strong>Sepet Görüntüleme:</strong> Header'daki sepet ikonu ile ulaşılan özel bir sayfada sepetteki ürünler, miktarları ve fiyatları (indirimler dahil) listelenir.</ListItem>
            <ListItem><strong>Miktar Güncelleme:</strong> Sepet sayfasında ürünlerin miktarları artırılabilir, azaltılabilir veya tamamen kaldırılabilir.</ListItem>
            <ListItem><strong>İndirimlerin Yansıması:</strong> Kullanıcının tanımlı iskonto oranı, sepetteki ürün fiyatlarına ve genel toplama otomatik olarak yansıtılır.</ListItem>
            <ListItem><strong>Sipariş Özeti:</strong> Ara toplam, uygulanan indirim ve genel toplam net bir şekilde gösterilir.</ListItem>
            <ListItem><strong>Siparişi Tamamlama ve Ödeme:</strong>
                <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Kullanıcılar sepetlerini onaylayarak sipariş oluşturabilirler. Bu sipariş, bir sipariş numarası ile kaydedilir ve durumu "Sepet Onaylandı" olarak başlar.</li>
                    <li><strong>Ödeme Yöntemi:</strong> Ödeme sadece **EFT/Havale** ile kabul edilmektedir. Sipariş tamamlama (sepet) sayfasında gerekli banka hesap bilgileri (IBAN, Hesap Sahibi, Banka Adı) müşteriye sunulur.</li>
                    <li>Kredi kartı ile ödeme seçeneğinin şu an için aktif olmadığı, ilerleyen dönemlerde ekleneceği belirtilir.</li>
                </ul>
            </ListItem>
        </ul>

        <SectionTitle>Sipariş Yönetimi ve Takip Özelliği</SectionTitle>
        <ul className="list-none pl-0">
            <ListItem><strong>Sipariş Oluşturma:</strong> Sipariş oluşturulduğunda "Sepet Onaylandı" durumuyla başlar. Müşteriye ödeme yapması gerektiği (simüle edilmiş e-posta/SMS ile) bildirilir.</ListItem>
            <ListItem><strong>Simüle Edilmiş E-posta/SMS Bildirimleri:</strong> Bir sipariş oluşturulduğunda veya durumu değiştiğinde (örn: "Sepet Onaylandı", "Ödeme Onaylandı", "Gemiye Yüklendi", "Teslim Edildi"), müşteriye ve ilgili durumlarda yöneticiye sipariş numarası ve yeni durum hakkında bilgilendirme gönderildiği **simüle edilir** (konsola log basılır).</ListItem>
            <ListItem><strong>Kapsamlı Sipariş Detay Sayfası:</strong>
                <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Kullanıcılar, "Siparişler" sayfasındaki sipariş numarasına tıklayarak ilgili siparişin detay sayfasına ulaşabilirler.</li>
                    <li>Bu sayfada siparişin tüm detayları (ürünler, fiyatlar, notlar, ödeme kanıtı linki vb.) görüntülenir.</li>
                </ul>
            </ListItem>
            <ListItem><strong>Adım Adım Sipariş Durumu Görselleştirmesi:</strong>
                 <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>Sipariş detay sayfasında, siparişin ilerlemesini gösteren görsel bir ilerleme çubuğu (adım göstergesi) bulunur.</li>
                    <li>Desteklenen Durumlar: Sepet Onaylandı, Ödeme Bekliyor, Ödeme Makbuzu Yüklendi, Ödeme Onaylandı, Sipariş Hazırlanıyor, Gemiye Yüklendi/Yola Çıktı, Yolda, Gümrükte, Teslimat Noktasına Yaklaştı, Teslim Edildi, İptal Edildi.</li>
                 </ul>
            </ListItem>
            <ListItem><strong>Sipariş Takibi ("Siparişler" Sayfası):</strong>
                <ul className="list-disc list-inside pl-5 mt-1 space-y-0.5 text-sm">
                    <li>**Süper Admin ve Yöneticiler:** Tüm siparişleri görüntüleyebilir, durumlarını güncelleyebilir, not ekleyebilir ve (simüle edilmiş) konteyner fotoğrafı yükleyebilirler.</li>
                    <li>**Müşteri Kullanıcıları:** Sadece kendi siparişlerini görüntüleyebilir. Ödeme bekleyen siparişleri için (simüle edilmiş) ödeme makbuzu yükleyebilir ve not ekleyebilirler.</li>
                </ul>
            </ListItem>
            <ListItem><strong>Demo Kalıcılığı:</strong> Siparişler, demo amacıyla tarayıcının yerel depolamasında saklanır.</ListItem>
        </ul>

        <SubSectionTitle>Yapay Zeka (YZ) Destekli Asistan</SubSectionTitle>
        <ul className="list-none pl-0">
          <ListItem><strong>Google Gemini API Entegrasyonu:</strong> Güçlü <code>gemini-2.5-flash-preview-04-17</code> modeli ile çalışır.</ListItem>
          <ListItem><strong>Kişiselleştirilmiş Karşılama ve Etkileşim.</strong></ListItem>
          <ListItem><strong>Google Arama Entegrasyonu ve Kaynak Gösterme.</strong></ListItem>
           <ListItem><strong>Otomatik İçerik Üretimi (Ürün Yönetimi):</strong> Eksik ürün açıklamaları ve placeholder resim URL'leri için öneriler sunar.</ListItem>
        </ul>

        <SectionTitle>Kullanılan Teknolojiler</SectionTitle>
        <ul className="list-none pl-0">
          <ListItem><strong>Frontend:</strong> React (v19), TypeScript</ListItem>
          <ListItem><strong>Stil:</strong> Tailwind CSS</ListItem>
          <ListItem><strong>YZ API:</strong> Google Gemini API (<code>@google/genai</code>)</ListItem>
        </ul>
        
        <SectionTitle>Gelecek Geliştirme Fikirleri (Bu Temel İskelet İçin)</SectionTitle>
        <ul className="list-none pl-0">
          <ListItem>Gerçek sipariş ve ödeme entegrasyonu (backend ile).</ListItem>
          <ListItem>Gerçek e-posta bildirim sistemi (backend ile).</ListItem>
          <ListItem>Detaylı kullanıcı aktivite logları.</ListItem>
          <ListItem>YZ asistanının kullanıcı bazlı yetkileri ve ürün bilgilerini daha derinlemesine anlaması.</ListItem>
          <ListItem>Toplu kullanıcı içe/dışa aktarma.</ListItem>
          <ListItem>Excel (.xlsx) formatında toplu ürün içe aktarma desteği (harici kütüphane ile).</ListItem>
        </ul>

        <div className="mt-10 pt-6 border-t border-slate-300 text-center">
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-700 hover:bg-orange-800 text-white font-bold py-3 px-8 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-75 text-lg"
            aria-label="Ürün kataloğuna geri dön"
          >
            Ürün Kataloğuna Geri Dön
          </button>
        </div>
      </div>
    </main>
  );
};

export default AboutPage;