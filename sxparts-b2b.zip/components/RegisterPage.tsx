
import React, { useState } from 'react';
import { User } from '../types'; // User tipini import et

interface RegisterPageProps {
  onRegister: (userData: Omit<User, 'id' | 'role' | 'discountRate' | 'accessibleCategories' | 'isActive' | 'canSetUserDiscounts' | 'canCreateNewUsers' | 'canManageAllProducts' | 'isPendingApproval' | 'password'> & { passwordInput: string; name: string; email: string; username: string; companyName?: string; taxId?: string; phoneNumber?: string; }) => void;
  onNavigateToLogin: () => void;
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onRegister, onNavigateToLogin }) => {
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [taxId, setTaxId] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [username, setUsername] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (passwordInput !== confirmPassword) {
      setError("Şifreler eşleşmiyor.");
      return;
    }
    if (!name || !email || !username || !passwordInput) {
        setError("Lütfen tüm zorunlu alanları (*) doldurun.");
        return;
    }

    setIsLoading(true);
    try {
      await onRegister({ 
        name, 
        email, 
        username, 
        passwordInput,
        companyName,
        taxId,
        phoneNumber 
      });
      // Başarılı kayıt sonrası yönlendirme App.tsx içinde handle ediliyor.
    } catch (err: any) {
      setError(err.message || "Kayıt sırasında bir hata oluştu.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-800 flex flex-col justify-center items-center p-4">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-lg">
        <div className="text-center mb-6">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto mb-4 text-orange-500">
            <path strokeLinecap="round" strokeLinejoin="round" d="M18 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
          </svg>
          <h1 className="text-3xl font-bold text-slate-700">Üyelik Talebi Oluşturun</h1>
          <p className="text-gray-600 mt-2">Hesabınız yönetici onayından sonra aktif olacaktır.</p>
        </div>
        
        <p className="text-sm text-gray-500 bg-blue-50 p-3 rounded-md border border-blue-200 mb-6 text-center">
            Platformumuz seçkin bir müşteri kitlesine özel olarak hizmet vermektedir ve üyelik talepleri titizlikle değerlendirilmektedir. Anlayışınız için teşekkür ederiz.
        </p>

        {error && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded-lg text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Ad Soyad <span className="text-red-500">*</span></label>
              <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
             <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">E-posta <span className="text-red-500">*</span></label>
              <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 mb-1">Şirket Adı</label>
                <input type="text" id="companyName" value={companyName} onChange={e => setCompanyName(e.target.value)} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
            <div>
                <label htmlFor="taxId" className="block text-sm font-medium text-gray-700 mb-1">Vergi Numarası</label>
                <input type="text" id="taxId" value={taxId} onChange={e => setTaxId(e.target.value)} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
          </div>
           <div>
              <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">Telefon Numarası</label>
              <input type="tel" id="phoneNumber" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
          
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">Kullanıcı Adı <span className="text-red-500">*</span></label>
            <input type="text" id="username" value={username} onChange={e => setUsername(e.target.value)} required className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Şifre <span className="text-red-500">*</span></label>
              <input type="password" id="password" value={passwordInput} onChange={e => setPasswordInput(e.target.value)} required className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">Şifre Tekrar <span className="text-red-500">*</span></label>
              <input type="password" id="confirmPassword" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500" />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-60"
            disabled={isLoading}
          >
            {isLoading ? 'Talep Gönderiliyor...' : 'Üyelik Talebi Gönder'}
          </button>
        </form>
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Zaten bir hesabınız var mı?{' '}
            <button
              onClick={onNavigateToLogin}
              className="font-medium text-orange-600 hover:text-orange-500"
              disabled={isLoading}
            >
              Giriş Yapın
            </button>
          </p>
        </div>
      </div>
      <footer className="text-center text-sm text-gray-400 py-6 mt-8">
        &copy; {new Date().getFullYear()} B2B Katalog Pro. Tüm hakları saklıdır.
      </footer>
    </div>
  );
};

export default RegisterPage;