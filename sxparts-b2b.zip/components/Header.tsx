
import React from 'react';
import ChatIcon from './icons/ChatIcon';
import SearchIcon from './icons/SearchIcon';
import ShoppingCartIcon from './icons/ShoppingCartIcon';
import DocumentTextIcon from './icons/DocumentTextIcon'; 
import { User, PageView } from '../types'; 
import { CubeIcon } from './icons/CubeIcon'; // Yeni ikon

interface HeaderProps {
  searchTerm: string;
  onSearchTermChange: (term: string) => void;
  onToggleChat: () => void;
  isChatOpen: boolean;
  currentUser: User; 
  onLogout: () => void;
  currentPage: PageView;
  navigateTo: (page: PageView) => void;
  cartItemCount: number; 
}

const Header: React.FC<HeaderProps> = ({ 
  searchTerm, 
  onSearchTermChange, 
  onToggleChat, 
  isChatOpen,
  currentUser,
  onLogout,
  currentPage,
  navigateTo,
  cartItemCount
}) => {
  const canAccessProductManagement = currentUser.role === 'super_admin' || (currentUser.role === 'manager' && currentUser.canManageAllProducts);

  return (
    <header className="bg-slate-800 text-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <div className="flex items-center">
           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10 mr-3 text-orange-400">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.353-.026.692-.026 1.032 0 1.13.094 1.976 1.057 1.976 2.192V7.5M8.25 7.5h7.5M8.25 7.5c0 1.135-.845 2.098-1.976 2.192a48.424 48.424 0 00-1.032 0C4.12 9.69 3.275 8.727 3.275 7.692V6.108c0-1.135.845-2.098 1.976-2.192a48.424 48.424 0 011.032 0c1.13.094 1.976 1.057 1.976 2.192V7.5m0 0c0 1.135.845 2.098 1.976 2.192.353-.026.692-.026 1.032 0 1.13.094 1.976 1.057 1.976 2.192V10.5A2.25 2.25 0 0018 12.75v.165c0 .541-.1.999-.275 1.436M18 12.75v2.036c0 .541-.1.999-.275 1.436M18 12.75c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.032 0c-1.13.094-1.976 1.057-1.976 2.192v2.036c0 .541.1.999.275 1.436m13.5 0c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.032 0c-1.13.094-1.976 1.057-1.976 2.192v4.436c0 .541.1.999.275 1.436M12 12.75h6M12 12.75c-1.135 0-2.098.845-2.192 1.976a48.424 48.424 0 000 1.032c.094 1.13 1.057 1.976 2.192 1.976h2.036c.541 0 .999-.1 1.436-.274M12 12.75V10.5M12 12.75c-1.135 0-2.098.845-2.192 1.976a48.424 48.424 0 000 1.032c.094 1.13 1.057 1.976 2.192 1.976H12M6.75 17.25h.008v.008H6.75v-.008zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
          </svg>
          <h1 
            className="text-xl sm:text-2xl font-bold tracking-tight cursor-pointer hover:text-orange-300 transition-colors"
            onClick={() => navigateTo('catalog')}
            role="button"
            tabIndex={0}
            aria-label="Ana kataloğa git"
            onKeyDown={(e) => e.key === 'Enter' && navigateTo('catalog')}
            >
                B2B Katalog Pro
            </h1>
        </div>
        <div className="flex items-center space-x-1 sm:space-x-2 md:space-x-3">
          {currentPage === 'catalog' && (
            <div className="relative">
                <input
                type="search"
                placeholder="Ürün ara..."
                value={searchTerm}
                onChange={(e) => onSearchTermChange(e.target.value)}
                className="bg-slate-700 text-white placeholder-gray-400 rounded-lg py-2 px-4 pl-10 focus:ring-2 focus:ring-orange-500 focus:outline-none transition-all w-28 sm:w-32 md:w-48 lg:w-56"
                aria-label="Ürünlerde ara"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="w-5 h-5 text-gray-400" />
                </div>
            </div>
          )}

          {currentPage !== 'catalog' && (
            <button
              onClick={() => navigateTo('catalog')}
              className="hidden sm:inline-block text-sm text-gray-300 hover:text-orange-400 transition-colors px-2 py-1 rounded-md hover:bg-slate-700"
              title="Kataloğa Geri Dön"
              aria-label="Kataloğa Geri Dön"
            >
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 inline-block mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
            </svg>
              <span className="hidden md:inline">Katalog</span>
            </button>
          )}
          
          {/* Ürün Yönetimi Butonu */}
          {canAccessProductManagement && currentPage !== 'product_management' && (
            <button
              onClick={() => navigateTo('product_management')}
              className="hidden sm:inline-block text-sm text-gray-300 hover:text-orange-400 transition-colors px-2 py-1 rounded-md hover:bg-slate-700"
              title="Toplu Ürün Yönetimi"
              aria-label="Ürün Yönetimi Sayfasına Git"
            >
              <CubeIcon className="w-5 h-5 inline-block mr-1" />
              <span className="hidden lg:inline">Ürün Yön.</span>
            </button>
          )}


          {currentUser.role === 'super_admin' && currentPage !== 'trash' && (
            <button
              onClick={() => navigateTo('trash')}
              className="hidden sm:inline-block text-sm text-gray-300 hover:text-orange-400 transition-colors px-2 py-1 rounded-md hover:bg-slate-700"
              title="Çöp Kutusunu Görüntüle"
              aria-label="Çöp Kutusunu Görüntüle"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 inline-block mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c.342.052.682.107 1.022.166m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
              </svg>
              <span className="hidden lg:inline">Çöp K.</span>
            </button>
          )}
          

          {currentUser.role === 'super_admin' && currentPage !== 'user_management' && (
            <button
              onClick={() => navigateTo('user_management')}
              className="hidden sm:inline-block text-sm text-gray-300 hover:text-orange-400 transition-colors px-2 py-1 rounded-md hover:bg-slate-700"
              title="Kullanıcı Yönetimi"
              aria-label="Kullanıcı Yönetimi Sayfasına Git"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 inline-block mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
              </svg>
              <span className="hidden lg:inline">K. Yön.</span>
            </button>
          )}
          
          {currentPage !== 'orders' && (
            <button
              onClick={() => navigateTo('orders')}
              className="hidden sm:inline-block p-1.5 sm:p-2 rounded-full hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
              aria-label="Siparişlerim"
              title="Siparişlerim"
            >
              <DocumentTextIcon className="w-5 h-5" />
            </button>
          )}

          {currentPage !== 'cart' && (
            <button
              onClick={() => navigateTo('cart')}
              className="relative p-1.5 sm:p-2 rounded-full hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
              aria-label="Alışveriş Sepetini Görüntüle"
              title="Alışveriş Sepeti"
            >
              <ShoppingCartIcon className="w-5 h-5 sm:w-6 sm:h-6" />
              {cartItemCount > 0 && (
                <span className="absolute top-0 right-0 block h-4 w-4 sm:h-5 sm:w-5 transform -translate-y-1/2 translate-x-1/2 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                  {cartItemCount > 9 ? '9+' : cartItemCount}
                </span>
              )}
            </button>
          )}


          <button
            onClick={onToggleChat}
            className={`p-1.5 sm:p-2 rounded-full hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors ${isChatOpen ? 'bg-orange-600' : ''}`}
            aria-label={isChatOpen ? "YZ Asistanını Kapat" : "YZ Asistanını Aç"}
          >
            <ChatIcon className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
          <div className="flex items-center space-x-2 sm:space-x-3">
            <span className="text-sm hidden xl:inline" title={currentUser.email}>Hoş geldin, {currentUser.name.split('(')[0].trim()}!</span>
             <span className="text-sm hidden sm:inline xl:hidden" title={currentUser.email}>{currentUser.name.split(' ')[0]}!</span>
            <button
              onClick={onLogout}
              className="bg-red-500 hover:bg-red-600 text-white text-xs sm:text-sm font-medium py-2 px-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-red-400"
              title="Oturumu Kapat"
            >
              Çıkış Yap
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;