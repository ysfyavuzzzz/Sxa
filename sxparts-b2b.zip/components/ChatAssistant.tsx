
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage as ChatMessageType, GroundingMetadata } from '../types';
import ChatMessageEntry from './ChatMessageEntry';
import CloseIcon from './icons/CloseIcon';
import LoadingSpinner from './LoadingSpinner';

interface ChatAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessageType[];
  onSendMessage: (message: string) => Promise<void>;
  isAiTyping: boolean;
  chatError: string | null;
  currentGroundingMetadata?: GroundingMetadata;
}

const ChatAssistant: React.FC<ChatAssistantProps> = ({ 
  isOpen, 
  onClose, 
  messages, 
  onSendMessage, 
  isAiTyping,
  chatError,
  currentGroundingMetadata
}) => {
  const [userInput, setUserInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages, isAiTyping]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userInput.trim() && !isAiTyping) {
      await onSendMessage(userInput.trim());
      setUserInput('');
    }
  };

  return (
    <div
      className={`fixed top-0 right-0 h-full bg-slate-50 shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col
        ${isOpen ? 'translate-x-0' : 'translate-x-full'} w-full max-w-md z-[60] border-l border-slate-300`}
    >
      <div className="flex items-center justify-between p-4 bg-slate-700 text-white">
        <h3 className="text-lg font-semibold">YZ Asistanı</h3>
        <button
          onClick={onClose}
          className="p-1 rounded-full hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-orange-400"
          aria-label="Sohbeti kapat"
        >
          <CloseIcon className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-grow p-4 overflow-y-auto bg-slate-100">
        {messages.map((msg, index) => (
          <ChatMessageEntry 
            key={msg.id} 
            message={msg} 
            groundingMetadata={index === messages.length - 1 && msg.sender === 'ai' ? currentGroundingMetadata : undefined}
          />
        ))}
        {isAiTyping && messages[messages.length -1]?.sender !== 'ai' && (
           <div className="flex justify-start mb-3">
             <div className="max-w-[80%] p-3 rounded-xl shadow bg-white text-gray-800 rounded-bl-none border border-gray-200">
                <LoadingSpinner size="sm" color="text-orange-600" />
             </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {chatError && (
        <div className="p-3 bg-red-100 text-red-700 text-sm">
          Hata: {chatError}
        </div>
      )}
      <form onSubmit={handleSubmit} className="p-4 border-t border-slate-300 bg-white">
        <div className="flex items-center space-x-2">
          <input
            ref={inputRef}
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            placeholder={isAiTyping ? "YZ yanıtlıyor..." : "Ürünler hakkında sorun..."}
            className="flex-grow p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none transition-colors"
            disabled={isAiTyping}
            aria-label="Mesajınızı yazın"
          />
          <button
            type="submit"
            className="bg-orange-600 text-white p-3 rounded-lg hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            disabled={isAiTyping || !userInput.trim()}
            aria-label="Mesaj gönder"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
            </svg>
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatAssistant;