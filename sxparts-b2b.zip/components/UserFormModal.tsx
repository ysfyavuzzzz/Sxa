
import React, { useState, useEffect } from 'react';
import { User, ProductCategory } from '../types';

interface UserFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (userData: Omit<User, 'id' | 'password'> & {passwordInput?: string; companyName?: string; taxId?: string; phoneNumber?: string; isPendingApproval?: boolean; canSetUserDiscounts?: boolean; canCreateNewUsers?: boolean; canManageAllProducts?: boolean;}, editingUser: User | null) => void;
  existingUser: User | null;
  allProductCategories: ProductCategory[];
  currentUser: User; 
}

const UserFormModal: React.FC<UserFormModalProps> = ({ 
    isOpen, 
    onClose, 
    onSubmit, 
    existingUser, 
    allProductCategories,
    currentUser 
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<'manager' | 'user'>('user');
  const [discountRate, setDiscountRate] = useState(0);
  const [accessibleCategories, setAccessibleCategories] = useState<ProductCategory[]>([]);
  const [isActive, setIsActive] = useState(true);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  // Yeni müşteri kayıt alanları
  const [companyName, setCompanyName] = useState('');
  const [taxId, setTaxId] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  // isPendingApproval bu formdan direkt yönetilmez, onApproveUser ile App.tsx'de yapılır.
  // Admin oluşturuyorsa false olur.

  const [canSetUserDiscounts, setCanSetUserDiscounts] = useState(false);
  const [canCreateNewUsers, setCanCreateNewUsers] = useState(false);
  const [canManageAllProducts, setCanManageAllProducts] = useState(false);


  useEffect(() => {
    if (existingUser) {
      setName(existingUser.name);
      setEmail(existingUser.email);
      setUsername(existingUser.username);
      setRole(existingUser.role === 'super_admin' ? 'manager' : existingUser.role); // Super admin rolü değiştirilemez
      setDiscountRate(existingUser.discountRate);
      setAccessibleCategories(existingUser.accessibleCategories || []);
      setIsActive(existingUser.isActive);
      setPasswordInput(''); 
      setConfirmPassword('');
      
      setCompanyName(existingUser.companyName || '');
      setTaxId(existingUser.taxId || '');
      setPhoneNumber(existingUser.phoneNumber || '');
      
      setCanSetUserDiscounts(!!existingUser.canSetUserDiscounts);
      setCanCreateNewUsers(!!existingUser.canCreateNewUsers);
      setCanManageAllProducts(!!existingUser.canManageAllProducts);

    } else {
      setName('');
      setEmail('');
      setUsername('');
      setPasswordInput('');
      setConfirmPassword('');
      setRole('user');
      setDiscountRate(0);
      setAccessibleCategories([]);
      setIsActive(true); // Admin oluşturuyorsa varsayılan aktif
      setCompanyName('');
      setTaxId('');
      setPhoneNumber('');
      setCanSetUserDiscounts(false);
      setCanCreateNewUsers(false);
      setCanManageAllProducts(false);
    }
    setPasswordError(null);
  }, [existingUser, isOpen]);

  const handleCategoryChange = (category: ProductCategory) => {
    setAccessibleCategories(prev =>
      prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    const determinedUserRoleForSubmit: User['role'] = existingUser?.role === 'super_admin' 
        ? 'super_admin' 
        : role;

    if (!existingUser && !passwordInput) {
        setPasswordError("Yeni kullanıcı için şifre gereklidir.");
        return;
    }
    if (passwordInput && passwordInput !== confirmPassword) {
        setPasswordError("Şifreler eşleşmiyor.");
        return;
    }

    const userData: Omit<User, 'id' | 'password'> & {passwordInput?: string; companyName?: string; taxId?: string; phoneNumber?: string; isPendingApproval?: boolean; canSetUserDiscounts?: boolean; canCreateNewUsers?: boolean; canManageAllProducts?: boolean;} = {
      name,
      email,
      username,
      role: determinedUserRoleForSubmit,
      discountRate: parseFloat(discountRate.toString()) || 0,
      accessibleCategories: (determinedUserRoleForSubmit === 'manager' || determinedUserRoleForSubmit === 'super_admin') 
        ? allProductCategories 
        : accessibleCategories,
      isActive,
      companyName,
      taxId,
      phoneNumber,
      isPendingApproval: existingUser ? existingUser.isPendingApproval : false, // Varolan kullanıcının onay durumunu koru, yeni admin-oluşturulan kullanıcı için false
    };

    if (passwordInput) {
        userData.passwordInput = passwordInput;
    }

    if (determinedUserRoleForSubmit === 'manager') {
        userData.canSetUserDiscounts = canSetUserDiscounts;
        userData.canCreateNewUsers = canCreateNewUsers;
        userData.canManageAllProducts = canManageAllProducts;
    }
    
    onSubmit(userData, existingUser);
  };

  if (!isOpen) return null;

  const isEditingSuperAdmin = existingUser?.role === 'super_admin';
  const canEditManagerPermissions = currentUser.role === 'super_admin' && role === 'manager' && !isEditingSuperAdmin;
  
  const canSetDiscountForTargetUser = 
    currentUser.role === 'super_admin' || 
    (currentUser.role === 'manager' && currentUser.canSetUserDiscounts && (existingUser?.role === 'user' || !existingUser));

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[70] p-4">
      <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <h2 className="text-2xl font-semibold mb-6 text-slate-700">
          {existingUser ? 'Kullanıcıyı Düzenle' : 'Yeni Kullanıcı Oluştur'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Ad, Email, Kullanıcı Adı */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Ad Soyad <span className="text-red-500">*</span></label>
              <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">E-posta <span className="text-red-500">*</span></label>
              <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">Kullanıcı Adı <span className="text-red-500">*</span></label>
              <input type="text" id="username" value={username} onChange={e => setUsername(e.target.value)} required className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
             <div>
              <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">Rol</label>
              <select 
                id="role" 
                value={role} 
                onChange={e => setRole(e.target.value as 'manager' | 'user')} 
                required 
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" 
                disabled={isEditingSuperAdmin || (currentUser.role === 'manager' && (existingUser?.role === 'manager' || existingUser?.role === 'super_admin'))}
              >
                <option value="user">Müşteri Kullanıcısı</option> 
                {(currentUser.role === 'super_admin') && <option value="manager">Yönetici</option>}
              </select>
               {isEditingSuperAdmin && <p className="text-xs text-amber-600 mt-1">Süper Admin rolü değiştirilemez.</p>}
               {currentUser.role === 'manager' && (existingUser?.role === 'manager' || existingUser?.role === 'super_admin') && <p className="text-xs text-amber-600 mt-1">Yöneticiler, diğer yöneticilerin veya süper adminin rolünü değiştiremez.</p>}
            </div>
          </div>

          {/* Şirket Bilgileri */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             <div>
                <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 mb-1">Şirket Adı</label>
                <input type="text" id="companyName" value={companyName} onChange={e => setCompanyName(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
             <div>
                <label htmlFor="taxId" className="block text-sm font-medium text-gray-700 mb-1">Vergi No</label>
                <input type="text" id="taxId" value={taxId} onChange={e => setTaxId(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
             <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">Telefon Numarası</label>
                <input type="tel" id="phoneNumber" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" />
            </div>
          </div>


          {/* Şifre Alanları */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label htmlFor="passwordInput" className="block text-sm font-medium text-gray-700 mb-1">
                    {'Şifre '} 
                    {existingUser ? '(Değiştirmek için doldurun)' : <span className="text-red-500">*</span>}
                </label>
                <input type="password" id="passwordInput" value={passwordInput} onChange={e => setPasswordInput(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" required={!existingUser} />
            </div>
            <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    {'Şifre Tekrar '} 
                    {existingUser && !passwordInput ? '' : <span className="text-red-500">*</span>}
                </label>
                <input type="password" id="confirmPassword" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" required={!existingUser || (existingUser && !!passwordInput)} />
            </div>
          </div>
          {passwordError && <p className="text-red-500 text-sm mb-1">{passwordError}</p>}


          {/* İskonto Oranı ve Aktif Durumu */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
            <div>
              <label htmlFor="discountRate" className="block text-sm font-medium text-gray-700 mb-1">İskonto Oranı (%)</label>
              <input 
                type="number" 
                id="discountRate" 
                value={discountRate * 100} 
                onChange={e => setDiscountRate(parseFloat(e.target.value) / 100)} 
                min="0" max="100" step="0.01" 
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500" 
                disabled={!canSetDiscountForTargetUser && !isEditingSuperAdmin}
              />
              {!canSetDiscountForTargetUser && !isEditingSuperAdmin && <p className="text-xs text-amber-600 mt-1">Bu kullanıcı için iskonto ayarlama yetkiniz yok.</p>}
            </div>
            <div>
               <label className="flex items-center space-x-2 cursor-pointer p-2">
                <input type="checkbox" checked={isActive} onChange={e => setIsActive(e.target.checked)} className="h-5 w-5 text-orange-600 border-gray-300 rounded focus:ring-orange-500" disabled={isEditingSuperAdmin || existingUser?.isPendingApproval} />
                <span className="text-sm font-medium text-gray-700">Aktif Kullanıcı</span>
              </label>
               {isEditingSuperAdmin && <p className="text-xs text-amber-600 ml-2">Süper Admin pasif yapılamaz.</p>}
               {existingUser?.isPendingApproval && <p className="text-xs text-yellow-600 ml-2">Kullanıcı onay bekliyor, önce onaylayın.</p>}
            </div>
          </div>
          
          {canEditManagerPermissions && (
            <div className="my-4 p-3 border border-orange-200 rounded-md bg-orange-50">
                <h4 className="text-md font-semibold text-orange-700 mb-2">Yönetici Yetkileri:</h4>
                <div className="space-y-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" checked={canSetUserDiscounts} onChange={e => setCanSetUserDiscounts(e.target.checked)} className="h-4 w-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500" />
                        <span className="text-sm text-gray-700">Diğer Kullanıcılara İskonto Belirleyebilir</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" checked={canCreateNewUsers} onChange={e => setCanCreateNewUsers(e.target.checked)} className="h-4 w-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500" />
                        <span className="text-sm text-gray-700">Yeni Müşteri Kullanıcısı Açabilir</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" checked={canManageAllProducts} onChange={e => setCanManageAllProducts(e.target.checked)} className="h-4 w-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500" />
                        <span className="text-sm text-gray-700">Ürünleri Yönetebilir (Kaldırma vb.)</span>
                    </label>
                </div>
            </div>
          )}


          {role === 'user' && (
            <div className="my-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Erişilebilir Kategoriler ('Müşteri Kullanıcısı' rolü için)</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-40 overflow-y-auto border p-2 rounded-md">
                {allProductCategories.map(category => (
                  <label key={category} className="flex items-center space-x-2 cursor-pointer p-1 hover:bg-gray-50 rounded">
                    <input
                      type="checkbox"
                      checked={accessibleCategories.includes(category)}
                      onChange={() => handleCategoryChange(category)}
                      className="h-4 w-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                    />
                    <span className="text-sm text-gray-700">{category}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
           {(role === 'manager' ) && !isEditingSuperAdmin && ( 
             <p className="text-sm text-gray-500 my-2 italic">'Yönetici' rolü tüm kategorilere erişebilir.</p>
           )}

          <div className="flex justify-end space-x-3 pt-4 border-t mt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md border border-gray-300"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
              disabled={isEditingSuperAdmin && existingUser?.id === currentUser.id && existingUser?.role === 'super_admin'}
            >
              {existingUser ? 'Güncelle' : 'Oluştur'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserFormModal;