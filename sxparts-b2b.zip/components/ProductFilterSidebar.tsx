
import React from 'react';
import { ProductCategory } from '../types';
// import { CATEGORIES } from '../constants'; // Artık direkt CATEGORIES kullanılmayacak

interface ProductFilterSidebarProps {
  selectedCategory: ProductCategory | null;
  onSelectCategory: (category: ProductCategory | null) => void;
  availableCategories: ProductCategory[]; // Kullanıcının erişebileceği kategoriler
}

const ProductFilterSidebar: React.FC<ProductFilterSidebarProps> = ({ 
  selectedCategory, 
  onSelectCategory,
  availableCategories 
}) => {
  if (availableCategories.length === 0) {
    return (
      <aside className="w-full md:w-64 bg-white p-6 shadow-lg rounded-lg h-fit sticky top-24">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Ürün Kategorileri</h3>
        <p className="text-sm text-gray-500">Erişebileceğiniz kategori bulunmamaktadır.</p>
      </aside>
    );
  }
  return (
    <aside className="w-full md:w-64 bg-white p-6 shadow-lg rounded-lg h-fit sticky top-24">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Ürün Kategorileri</h3>
      <nav>
        <ul>
          <li>
            <button
              onClick={() => onSelectCategory(null)}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium transition-colors
                ${selectedCategory === null ? 'bg-orange-100 text-orange-700' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              Tüm Ürünler
            </button>
          </li>
          {availableCategories.map((category) => (
            <li key={category} className="mt-1">
              <button
                onClick={() => onSelectCategory(category)}
                className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium transition-colors
                  ${selectedCategory === category ? 'bg-orange-100 text-orange-700' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
              >
                {category}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default ProductFilterSidebar;