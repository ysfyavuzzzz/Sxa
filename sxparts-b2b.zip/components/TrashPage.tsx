
import React from 'react';
import { Product } from '../types';

interface TrashPageProps {
  trashedProducts: Product[];
  onRestoreProduct: (productId: string) => void;
  onPermanentDeleteProduct: (productId: string) => void;
  onEmptyTrash: () => void;
  onNavigateToCatalog: () => void;
}

const TrashPage: React.FC<TrashPageProps> = ({ 
  trashedProducts, 
  onRestoreProduct, 
  onPermanentDeleteProduct,
  onEmptyTrash,
  onNavigateToCatalog
}) => {
  return (
    <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <h1 className="text-3xl font-bold text-slate-800 mb-4 sm:mb-0">
            Çöp Kutusu (Sadece Süper Admin)
          </h1>
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 self-start sm:self-center"
            aria-label="Ürün kataloğuna geri dön"
          >
            Kataloğa Dön
          </button>
        </div>

        {trashedProducts.length === 0 ? (
          <p className="text-gray-600 text-center py-10">Çöp kutusu boş.</p>
        ) : (
          <>
            <div className="mb-6 flex justify-end">
                <button
                    onClick={() => {
                        if (window.confirm("Çöp kutusundaki tüm ürünleri kalıcı olarak silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.")) {
                            onEmptyTrash();
                        }
                    }}
                    className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
                    aria-label="Tüm çöpü boşalt"
                    disabled={trashedProducts.length === 0}
                >
                    Tüm Çöpü Boşalt
                </button>
            </div>
            <div className="space-y-4">
            {trashedProducts.map(product => (
              <div key={product.id} className="bg-gray-50 p-4 rounded-lg shadow flex flex-col sm:flex-row justify-between items-center gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-slate-700">{product.name}</h3>
                  <p className="text-sm text-gray-500">Kategori: {product.category}</p>
                  <p className="text-sm text-gray-500">ID: {product.id}</p>
                </div>
                <div className="flex space-x-2 mt-2 sm:mt-0">
                  <button
                    onClick={() => onRestoreProduct(product.id)}
                    className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm"
                    aria-label={`'${product.name}' ürününü geri yükle`}
                  >
                    Geri Yükle
                  </button>
                  <button
                    onClick={() => {
                        if (window.confirm(`'${product.name}' ürününü kalıcı olarak silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.`)) {
                            onPermanentDeleteProduct(product.id);
                        }
                    }}
                    className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm"
                    aria-label={`'${product.name}' ürününü kalıcı olarak sil`}
                  >
                    Kalıcı Sil
                  </button>
                </div>
              </div>
            ))}
          </div>
          </>
        )}
      </div>
    </main>
  );
};

export default TrashPage;