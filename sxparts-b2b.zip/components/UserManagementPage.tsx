
import React, { useState } from 'react';
import { User, ProductCategory } from '../types';
import { CATEGORIES as ALL_CATEGORIES } from '../constants';
import UserFormModal from './UserFormModal';

interface UserManagementPageProps {
  users: User[];
  onCreateUser: (newUserData: Omit<User, 'id' | 'password'> & {passwordInput: string}) => void;
  onUpdateUser: (updatedUserData: User) => void;
  onToggleUserStatus: (userId: string) => void;
  onApproveUser: (userId: string) => void; // Yeni prop
  currentUser: User; 
  onNavigateToCatalog: () => void;
}

const UserManagementPage: React.FC<UserManagementPageProps> = ({
  users,
  onCreateUser,
  onUpdateUser,
  onToggleUserStatus,
  onApproveUser, // Prop olarak alındı
  currentUser,
  onNavigateToCatalog,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const openCreateModal = () => {
    setEditingUser(null);
    setIsModalOpen(true);
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingUser(null);
  };

  const handleFormSubmit = (userData: Omit<User, 'id' | 'password'> & {passwordInput?: string}, currentEditingUser: User | null) => {
    if (currentEditingUser) {
        const updatedUser: User = {
            ...currentEditingUser,
            name: userData.name,
            email: userData.email,
            username: userData.username,
            role: userData.role,
            discountRate: userData.discountRate,
            accessibleCategories: userData.accessibleCategories,
            isActive: userData.isActive,
            companyName: userData.companyName,
            taxId: userData.taxId,
            phoneNumber: userData.phoneNumber,
            // isPendingApproval admin tarafından düzenlenmez, onApproveUser ile yapılır.
            canSetUserDiscounts: userData.role === 'manager' ? userData.canSetUserDiscounts : undefined,
            canCreateNewUsers: userData.role === 'manager' ? userData.canCreateNewUsers : undefined,
            canManageAllProducts: userData.role === 'manager' ? userData.canManageAllProducts : undefined,
        };
        if (userData.passwordInput) {
            updatedUser.password = userData.passwordInput;
        }
        onUpdateUser(updatedUser);
    } else {
      if (!userData.passwordInput) {
        alert("Yeni kullanıcı için şifre gereklidir.");
        return;
      }
      const newUserCreatablePart: Omit<User, 'id' | 'password'> & {passwordInput: string} = {
        name: userData.name,
        email: userData.email,
        username: userData.username,
        role: userData.role,
        discountRate: userData.discountRate,
        accessibleCategories: userData.accessibleCategories,
        isActive: userData.isActive, // Admin oluşturuyorsa direkt aktif olabilir
        passwordInput: userData.passwordInput,
        companyName: userData.companyName,
        taxId: userData.taxId,
        phoneNumber: userData.phoneNumber,
        isPendingApproval: false, // Admin tarafından oluşturulanlar direkt onaylı
        canSetUserDiscounts: userData.role === 'manager' ? userData.canSetUserDiscounts : undefined,
        canCreateNewUsers: userData.role === 'manager' ? userData.canCreateNewUsers : undefined,
        canManageAllProducts: userData.role === 'manager' ? userData.canManageAllProducts : undefined,
      };
      onCreateUser(newUserCreatablePart);
    }
    closeModal();
  };
  
  const getRoleDisplayName = (role: User['role']) => {
    switch (role) {
      case 'super_admin': return 'Süper Admin';
      case 'manager': return 'Yönetici';
      case 'user': return 'Müşteri Kullanıcısı';
      default: return role;
    }
  };

  const canCurrentUserCreateUsers = () => {
    if (currentUser.role === 'super_admin') return true;
    if (currentUser.role === 'manager' && currentUser.canCreateNewUsers) return true;
    return false;
  }

  return (
    <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <h1 className="text-3xl font-bold text-slate-800 mb-4 sm:mb-0">
            Kullanıcı Yönetim Paneli
          </h1>
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 self-start sm:self-center"
          >
            Kataloğa Dön
          </button>
        </div>

        {canCurrentUserCreateUsers() && (
          <div className="mb-6 flex justify-end">
            <button
              onClick={openCreateModal}
              className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
            >
              Yeni Kullanıcı Ekle
            </button>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ad Soyad</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">E-posta</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">K.Adı</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rol</th>
                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden md:table-cell">Şirket Adı</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden lg:table-cell">Vergi No</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden lg:table-cell">Telefon</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İskonto</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id} className={`${!user.isActive && !user.isPendingApproval ? 'bg-gray-100 opacity-70' : ''} ${user.isPendingApproval ? 'bg-yellow-50' : ''}`}>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-800">{user.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{user.email}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{user.username}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{getRoleDisplayName(user.role)}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 hidden md:table-cell">{user.companyName || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 hidden lg:table-cell">{user.taxId || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 hidden lg:table-cell">{user.phoneNumber || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{(user.discountRate * 100).toFixed(0)}%</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm">
                    {user.isPendingApproval ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-200 text-yellow-800">
                            Onay Bekliyor
                        </span>
                    ) : (
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {user.isActive ? 'Aktif' : 'Pasif'}
                        </span>
                    )}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => openEditModal(user)}
                      className="text-orange-600 hover:text-orange-800 disabled:opacity-50"
                      disabled={user.role === 'super_admin' && user.id !== currentUser.id}
                      title={user.role === 'super_admin' && user.id !== currentUser.id ? "Bu süper admin düzenlenemez" : "Düzenle"}
                    >
                      Düzenle
                    </button>
                    {user.isPendingApproval && (currentUser.role === 'super_admin' || (currentUser.role === 'manager' /*&& currentUser.canApproveUsers - bu yetki eklenebilir*/)) && (
                        <button
                            onClick={() => onApproveUser(user.id)}
                            className="text-green-600 hover:text-green-800"
                        >
                            Onayla
                        </button>
                    )}
                    {user.role !== 'super_admin' && !user.isPendingApproval && (
                       <button
                        onClick={() => onToggleUserStatus(user.id)}
                        className={`${user.isActive ? 'text-amber-600 hover:text-amber-800' : 'text-green-600 hover:text-green-800'}`}
                      >
                        {user.isActive ? 'Pasif Yap' : 'Aktif Yap'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <UserFormModal
          isOpen={isModalOpen}
          onClose={closeModal}
          onSubmit={handleFormSubmit}
          existingUser={editingUser}
          allProductCategories={ALL_CATEGORIES} // Bu aslında INITIAL_CATEGORIES olmalı veya App.tsx'deki dinamik kategori listesi
          currentUser={currentUser} 
        />
      )}
    </main>
  );
};

export default UserManagementPage;