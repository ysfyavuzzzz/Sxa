
import React from 'react';
import { CartItem, User, Product, Order } from '../types';
import ShoppingCartIcon from './icons/ShoppingCartIcon'; 
import CloseIcon from './icons/CloseIcon'; 

interface CartPageProps {
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, newQuantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  currentUser: User;
  onNavigateToCatalog: () => void;
  subtotal: number;
  totalDiscount: number;
  grandTotal: number;
  onCreateOrder: () => Promise<Order | null>; // Sipariş oluşturma fonksiyonu prop'u
}

const CartPage: React.FC<CartPageProps> = ({
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  currentUser,
  onNavigateToCatalog,
  subtotal,
  totalDiscount,
  grandTotal,
  onCreateOrder, // Prop olarak alındı
}) => {

  const handleQuantityChange = (item: CartItem, newQuantityStr: string) => {
    let newQuantity = parseInt(newQuantityStr, 10);
    if (isNaN(newQuantity) || newQuantity < 0) {
        newQuantity = 0; 
    }
    onUpdateQuantity(item.product.id, newQuantity);
  };

  const incrementQuantity = (item: CartItem) => {
    onUpdateQuantity(item.product.id, item.quantity + 1);
  };

  const decrementQuantity = (item: CartItem) => {
    onUpdateQuantity(item.product.id, item.quantity - 1);
  };

  const handleConfirmOrder = async () => {
    if (cartItems.length === 0) {
      alert("Sepetiniz boş. Lütfen sipariş vermek için ürün ekleyin.");
      return;
    }
    const createdOrder = await onCreateOrder();
    if (createdOrder) {
      // Sipariş başarıyla oluşturuldu mesajı veya yönlendirme App.tsx'de handle ediliyor.
    } else {
      // Sipariş oluşturma başarısız olduysa burada bir hata mesajı gösterilebilir.
    }
  };


  return (
    <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 pb-4 border-b border-slate-300">
          <div className="flex items-center mb-4 sm:mb-0">
            <ShoppingCartIcon className="w-10 h-10 mr-3 text-orange-600" />
            <h1 className="text-3xl font-bold text-slate-800">
              Alışveriş Sepetiniz
            </h1>
          </div>
          <button
            onClick={onNavigateToCatalog}
            className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50 self-start sm:self-center"
            aria-label="Alışverişe Devam Et"
          >
            Alışverişe Devam Et
          </button>
        </div>

        {cartItems.length === 0 ? (
          <div className="text-center py-12">
            <ShoppingCartIcon className="w-24 h-24 mx-auto text-gray-300 mb-4" />
            <p className="text-xl text-gray-600 mb-2">Sepetiniz şu anda boş.</p>
            <p className="text-gray-500 mb-6">Görünüşe göre henüz bir şey eklememişsiniz. Harika ürünlerimize göz atın!</p>
            <button
                onClick={onNavigateToCatalog}
                className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-lg transition-colors text-lg"
            >
                Kataloğa Göz At
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Sepet Ürünleri Listesi */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map(item => {
                const discountedItemPrice = item.product.price * (1 - currentUser.discountRate);
                const hasItemDiscount = currentUser.discountRate > 0 && discountedItemPrice < item.product.price;
                const itemTotalPrice = discountedItemPrice * item.quantity;

                return (
                  <div key={item.product.id} className="bg-gray-50 p-4 rounded-lg shadow-sm flex flex-col sm:flex-row items-center gap-4">
                    <img 
                        src={item.product.imageUrl} 
                        alt={item.product.name} 
                        className="w-24 h-24 object-cover rounded-md border" 
                        onError={(e) => (e.currentTarget.src = 'https://picsum.photos/100/100?grayscale')}
                    />
                    <div className="flex-grow text-center sm:text-left">
                      <h3 className="text-lg font-semibold text-slate-700">{item.product.name}</h3>
                      <p className="text-sm text-gray-500">{item.product.category}</p>
                       {hasItemDiscount ? (
                        <p className="text-sm">
                            <span className="text-green-600 font-semibold">${discountedItemPrice.toFixed(2)}</span>
                            <span className="text-gray-500 line-through ml-2">${item.product.price.toFixed(2)}</span>
                        </p>
                        ) : (
                        <p className="text-sm text-slate-600 font-semibold">${item.product.price.toFixed(2)}</p>
                        )}
                    </div>
                    <div className="flex items-center space-x-2 my-2 sm:my-0">
                      <button onClick={() => decrementQuantity(item)} disabled={item.quantity <= 1} className="p-1.5 border rounded-md hover:bg-gray-200 disabled:opacity-50">-</button>
                      <input 
                        type="number" 
                        value={item.quantity} 
                        onChange={(e) => handleQuantityChange(item, e.target.value)}
                        min="1"
                        max={item.product.stock}
                        className="w-12 text-center border-y border-gray-300 p-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500"
                        aria-label={`${item.product.name} adet`}
                      />
                      <button onClick={() => incrementQuantity(item)} disabled={item.quantity >= item.product.stock} className="p-1.5 border rounded-md hover:bg-gray-200 disabled:opacity-50">+</button>
                    </div>
                    <p className="font-semibold text-slate-700 w-24 text-center sm:text-right">${itemTotalPrice.toFixed(2)}</p>
                    <button onClick={() => onRemoveItem(item.product.id)} className="text-red-500 hover:text-red-700 p-1" title="Ürünü Kaldır">
                      <CloseIcon className="w-5 h-5"/>
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Sepet Özeti */}
            <div className="lg:col-span-1 bg-slate-100 p-6 rounded-lg shadow-md h-fit sticky top-24">
              <h2 className="text-xl font-semibold text-slate-800 mb-4 pb-3 border-b">Sipariş Özeti</h2>
              <div className="space-y-3 text-sm mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Ara Toplam:</span>
                  <span className="font-medium text-gray-800">${subtotal.toFixed(2)}</span>
                </div>
                {totalDiscount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span className="text-gray-600">İndirim ({ (currentUser.discountRate * 100).toFixed(0) }%):</span>
                    <span className="font-medium">-${totalDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-semibold text-slate-800 pt-3 border-t mt-3">
                  <span>Genel Toplam:</span>
                  <span>${grandTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 p-4 rounded-md mb-6">
                  <h3 className="text-md font-semibold text-blue-800 mb-2">Ödeme Bilgileri (EFT/Havale)</h3>
                  <p className="text-sm text-gray-700"><strong>Banka Adı:</strong> Örnek Bank A.Ş.</p>
                  <p className="text-sm text-gray-700"><strong>Hesap Sahibi:</strong> B2B Katalog Pro Tic. Ltd. Şti.</p>
                  <p className="text-sm text-gray-700"><strong>IBAN:</strong> TR00 0000 0000 0000 0000 0000</p>
                  <p className="text-xs text-gray-600 mt-2">Lütfen açıklama kısmına sipariş numaranızı yazmayı unutmayın.</p>
                  <p className="text-xs text-amber-700 mt-3 font-medium">
                    Not: Kredi kartı ile ödeme seçeneği şu anda aktif değildir. İlerleyen dönemde eklenecektir.
                  </p>
              </div>

              <button
                onClick={handleConfirmOrder}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition-colors text-base disabled:opacity-70"
                disabled={cartItems.length === 0}
              >
                Siparişi Tamamla (EFT/Havale)
              </button>
              <button
                onClick={() => {
                    if (window.confirm("Sepetinizdeki tüm ürünleri silmek istediğinizden emin misiniz?")) {
                        onClearCart();
                    }
                }}
                className="mt-3 w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm disabled:opacity-70"
                disabled={cartItems.length === 0}
                >
                Sepeti Temizle
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

export default CartPage;