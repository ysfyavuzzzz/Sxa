
import React, { useState } from 'react';
import { Product, User } from '../types';

interface ProductCardProps {
  product: Product;
  onSoftDelete?: (productId: string) => void;
  currentUser: User;
  onAddToCart: (product: Product, quantity: number) => void; // Sepete ekleme fonksiyonu
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSoftDelete, currentUser, onAddToCart }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [cardQuantity, setCardQuantity] = useState(1);

  const canManageProduct = currentUser.role === 'super_admin' || (currentUser.role === 'manager' && currentUser.canManageAllProducts);
  
  const discountedPrice = product.price * (1 - currentUser.discountRate);
  const hasDiscount = currentUser.discountRate > 0 && discountedPrice < product.price;

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = parseInt(e.target.value, 10);
    if (isNaN(value) || value < 1) {
      value = 1;
    } else if (value > product.stock) {
      value = product.stock;
    }
    setCardQuantity(value);
  };

  const incrementQuantity = () => {
    setCardQuantity(prev => Math.min(product.stock, prev + 1));
  };

  const decrementQuantity = () => {
    setCardQuantity(prev => Math.max(1, prev - 1));
  };

  const handleAddToCartClick = () => {
    if (product.stock > 0 && cardQuantity > 0 && cardQuantity <= product.stock) {
      onAddToCart(product, cardQuantity);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl flex flex-col">
      <img 
        className="w-full h-56 object-cover" 
        src={product.imageUrl} 
        alt={product.name} 
        onError={(e) => (e.currentTarget.src = 'https://picsum.photos/600/400?grayscale')} 
      />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
        <p className="text-xs text-orange-600 font-medium uppercase tracking-wider mb-3">{product.category}</p>
        <p className="text-gray-600 text-sm mb-4 flex-grow">{product.description}</p>
        
        <div className="mt-auto">
            <div className="flex justify-between items-center mb-4">
                <div>
                    {hasDiscount ? (
                        <>
                            <p className="text-xl font-bold text-green-600">${discountedPrice.toFixed(2)}</p>
                            <p className="text-sm text-gray-500 line-through">
                                ${product.price.toFixed(2)}
                                <span className="ml-1 text-green-700 font-semibold">({(currentUser.discountRate * 100).toFixed(0)}% indirim)</span>
                            </p>
                        </>
                    ) : (
                        <p className="text-2xl font-bold text-slate-700">${product.price.toFixed(2)}</p>
                    )}
                </div>
                <span className={`text-sm font-semibold px-3 py-1 rounded-full ${product.stock > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                {product.stock > 0 ? `${product.stock} stokta` : 'Stokta Yok'}
                </span>
            </div>

            {isExpanded && (
                <div className="text-sm text-gray-700 mt-4 pt-4 border-t">
                    <h4 className="font-semibold mb-2">Özellikler:</h4>
                    <ul className="list-disc list-inside space-y-1">
                    {Object.entries(product.specifications).map(([key, value]) => (
                        <li key={key}>
                        <span className="font-medium">{key}:</span> {value}
                        </li>
                    ))}
                    </ul>
                </div>
            )}

            {/* Adet Seçimi ve Sepete Ekle Butonu */}
            {product.stock > 0 && (
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between sm:justify-start space-x-2">
                  <span className="text-sm font-medium text-gray-700">Adet:</span>
                  <div className="flex items-center border border-gray-300 rounded-md">
                    <button
                      onClick={decrementQuantity}
                      disabled={cardQuantity <= 1}
                      className="px-3 py-1.5 text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed rounded-l-md focus:outline-none focus:ring-1 focus:ring-orange-500"
                      aria-label="Adedi azalt"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      value={cardQuantity}
                      onChange={handleQuantityChange}
                      min="1"
                      max={product.stock}
                      className="w-12 text-center border-l border-r border-gray-300 focus:outline-none focus:ring-1 focus:ring-orange-500 py-1.5"
                      aria-label="Ürün adedi"
                    />
                    <button
                      onClick={incrementQuantity}
                      disabled={cardQuantity >= product.stock}
                      className="px-3 py-1.5 text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed rounded-r-md focus:outline-none focus:ring-1 focus:ring-orange-500"
                      aria-label="Adedi artır"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button
                  onClick={handleAddToCartClick}
                  disabled={product.stock === 0 || cardQuantity <= 0 || cardQuantity > product.stock}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  Sepete Ekle
                </button>
              </div>
            )}
            {product.stock === 0 && (
                 <p className="mt-4 text-sm text-center text-red-600 font-medium">Bu ürün şu anda stokta bulunmamaktadır.</p>
            )}

            <div className="space-y-2 mt-4">
                <button
                    onClick={() => setIsExpanded(!isExpanded)}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-opacity-50"
                >
                    {isExpanded ? 'Daha Az Göster' : 'Detayları Gör'}
                </button>
                {canManageProduct && onSoftDelete && (
                    <button
                        onClick={() => onSoftDelete(product.id)}
                        className="w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-opacity-50"
                        aria-label={`'${product.name}' ürününü kaldır`}
                    >
                        Ürünü Kaldır
                    </button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;